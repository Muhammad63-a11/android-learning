package com.example.ui.components

import android.media.MediaPlayer
import android.net.Uri
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.VideoView
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.viewinterop.AndroidView
import java.io.File

@Composable
fun VideoPlayerView(
    videoPath: String,
    modifier: Modifier = Modifier,
    isLooping: Boolean = true,
    volume: Float = 1.0f,
    onPrepared: (durationMs: Int) -> Unit = {}
) {
    var videoViewRef = remember { mutableListOf<VideoView>() }

    Box(
        modifier = modifier.background(Color.Black),
        contentAlignment = Alignment.Center
    ) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                VideoView(ctx).apply {
                    layoutParams = FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )

                    setOnPreparedListener { mp ->
                        try {
                            mp.isLooping = isLooping
                            mp.setVolume(volume, volume)
                            onPrepared(mp.duration)
                            start()
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }

                    setOnCompletionListener {
                        if (isLooping) {
                            try {
                                start()
                            } catch (e: Exception) {
                                e.printStackTrace()
                            }
                        }
                    }

                    setOnErrorListener { _, _, _ ->
                        // Prevent error dialogs and handle gracefully
                        true
                    }

                    tag = videoPath
                    val file = File(videoPath)
                    if (file.exists()) {
                        setVideoPath(videoPath)
                    } else if (videoPath.isNotEmpty()) {
                        setVideoURI(Uri.parse(videoPath))
                    }
                    videoViewRef.clear()
                    videoViewRef.add(this)
                }
            },
            update = { videoView ->
                videoViewRef.clear()
                videoViewRef.add(videoView)
                // Only re-set datasource if the video path actually changed
                if (videoView.tag != videoPath && videoPath.isNotEmpty()) {
                    videoView.tag = videoPath
                    val file = File(videoPath)
                    if (file.exists()) {
                        videoView.setVideoPath(videoPath)
                    } else {
                        videoView.setVideoURI(Uri.parse(videoPath))
                    }
                }
            }
        )
    }

    DisposableEffect(videoPath) {
        onDispose {
            try {
                videoViewRef.firstOrNull()?.stopPlayback()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}

