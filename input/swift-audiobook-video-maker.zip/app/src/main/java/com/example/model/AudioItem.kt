package com.example.model

data class AudioItem(
    val id: String,
    val title: String,
    val durationMs: Long,
    val filePath: String,
    val uriString: String = "",
    val volume: Float = 1.0f,
    val fadeInSec: Float = 0f,
    val fadeOutSec: Float = 0f,
    val startTrimMs: Long = 0L,
    val endTrimMs: Long = 0L,
    val isTtsGenerated: Boolean = false,
    val ttsText: String = "",
    val ttsVoice: String = "",
    val ttsLanguage: String = "",
    val ttsSpeed: Float = 1.0f,
    val ttsPitch: Int = 0
) {
    val effectiveDurationMs: Long
        get() {
            val end = if (endTrimMs > 0L) endTrimMs else durationMs
            return (end - startTrimMs).coerceAtLeast(1000L)
        }

    val durationFormatted: String
        get() {
            val totalSeconds = effectiveDurationMs / 1000
            val minutes = totalSeconds / 60
            val seconds = totalSeconds % 60
            return String.format("%02d:%02d", minutes, seconds)
        }
}
