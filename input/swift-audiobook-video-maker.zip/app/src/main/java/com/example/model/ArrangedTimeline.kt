package com.example.model

enum class LoopStrategy(val displayName: String, val description: String) {
    CENTER_CLIP_LOOP(
        "Center Clip Loop",
        "1st clip plays once as Intro, last clip plays once as Outro, center clips loop with second-to-last trimmed to fit."
    ),
    REPEAT_ALL_CLIPS(
        "Repeat All Clips",
        "Cycles through all selected clips in sequence from start to finish, trimming the last segment to match exact duration."
    ),
    REPEAT_CUSTOM_CLIP(
        "Repeat Custom Clip",
        "Repeats a specific selected clip in the loop while playing others once."
    )
}

enum class SegmentRole {
    INTRO_FIRST,
    CENTER_LOOP,
    SECOND_LAST_TRIMMED,
    OUTRO_LAST,
    SINGLE_REPEATING,
    CUSTOM_LOOP_SEGMENT
}

data class TimelineSegment(
    val index: Int,
    val clipId: String,
    val clipTitle: String,
    val clipFilePath: String,
    val segmentStartMs: Long,
    val segmentEndMs: Long,
    val segmentDurationMs: Long,
    val sourceClipTrimStartMs: Long = 0L,
    val sourceClipTrimEndMs: Long,
    val isFinalTrimmedSegment: Boolean = false,
    val role: SegmentRole = SegmentRole.CENTER_LOOP,
    val originalClipDurationMs: Long = segmentDurationMs
) {
    val isTrimmed: Boolean
        get() = role == SegmentRole.SECOND_LAST_TRIMMED || isFinalTrimmedSegment || segmentDurationMs < originalClipDurationMs

    val durationFormatted: String
        get() {
            val totalSec = segmentDurationMs / 1000
            val min = totalSec / 60
            val sec = totalSec % 60
            return String.format("%02d:%02d", min, sec)
        }

    val timeRangeFormatted: String
        get() {
            fun format(ms: Long): String {
                val totalSec = ms / 1000
                val min = totalSec / 60
                val sec = totalSec % 60
                return String.format("%02d:%02d", min, sec)
            }
            return "${format(segmentStartMs)} - ${format(segmentEndMs)}"
        }

    val roleLabel: String
        get() = when (role) {
            SegmentRole.INTRO_FIRST -> "Intro (1st Clip)"
            SegmentRole.CENTER_LOOP -> "Center Loop"
            SegmentRole.SECOND_LAST_TRIMMED -> "Second Last (Trimmed to Fit)"
            SegmentRole.OUTRO_LAST -> "Outro (Final Clip)"
            SegmentRole.SINGLE_REPEATING -> "Repeating Loop"
            SegmentRole.CUSTOM_LOOP_SEGMENT -> "Custom Repeating Clip"
        }
}

data class ArrangedTimeline(
    val targetAudioDurationMs: Long,
    val audioStartOffsetMs: Long = 0L,
    val audioEndOffsetMs: Long = 0L,
    val totalVideoDurationMs: Long,
    val loopStrategy: LoopStrategy = LoopStrategy.CENTER_CLIP_LOOP,
    val singleCycleDurationMs: Long,
    val fullCyclesCount: Int,
    val remainingMs: Long,
    val totalSegmentsCount: Int,
    val trimmedSegmentTitle: String?,
    val trimmedDurationMs: Long,
    val originalDurationOfTrimmedClipMs: Long,
    val segments: List<TimelineSegment>
) {
    val targetDurationFormatted: String
        get() = formatDuration(totalVideoDurationMs)

    val totalVideoDurationFormatted: String
        get() = formatDuration(totalVideoDurationMs)

    val audioDurationFormatted: String
        get() = formatDuration(targetAudioDurationMs)

    val audioSpanFormatted: String
        get() {
            val start = formatDuration(audioStartOffsetMs)
            val end = formatDuration(audioStartOffsetMs + targetAudioDurationMs)
            return "$start - $end"
        }

    val singleCycleFormatted: String
        get() = formatDuration(singleCycleDurationMs)

    val trimmedFormatted: String
        get() = formatDuration(trimmedDurationMs)

    val hasTrimmedSecondLast: Boolean
        get() = segments.any { it.role == SegmentRole.SECOND_LAST_TRIMMED }

    val introSegment: TimelineSegment?
        get() = segments.firstOrNull { it.role == SegmentRole.INTRO_FIRST }

    val outroSegment: TimelineSegment?
        get() = segments.lastOrNull { it.role == SegmentRole.OUTRO_LAST }

    val centerSegments: List<TimelineSegment>
        get() = segments.filter { it.role == SegmentRole.CENTER_LOOP || it.role == SegmentRole.SECOND_LAST_TRIMMED || it.role == SegmentRole.CUSTOM_LOOP_SEGMENT }

    /**
     * Finds the active segment at a given timestamp in milliseconds.
     */
    fun getSegmentAtTime(timeMs: Long): TimelineSegment? {
        if (segments.isEmpty()) return null
        val clampedTime = timeMs.coerceIn(0L, totalVideoDurationMs)
        return segments.find { clampedTime >= it.segmentStartMs && clampedTime < it.segmentEndMs }
            ?: segments.lastOrNull()
    }

    companion object {
        /**
         * Calculates the audiobook video timeline with full precision:
         * - Audio Start Offset (Pre-roll delay): audio begins after start offset ms
         * - Audio End Offset (Post-roll padding): video continues after audio completes
         * - Total Video Duration = Audio Duration + Start Offset + End Offset
         * - Supports Center Clip Looping, Repeat All Clips, and Custom Clip Looping
         */
        fun calculate(
            selectedClips: List<ClipItem>,
            audioDurationMs: Long,
            audioStartOffsetMs: Long = 0L,
            audioEndOffsetMs: Long = 0L,
            loopStrategy: LoopStrategy = LoopStrategy.CENTER_CLIP_LOOP,
            customRepeatClipId: String? = null
        ): ArrangedTimeline {
            val totalVideoDurationMs = (audioDurationMs + audioStartOffsetMs + audioEndOffsetMs).coerceAtLeast(1000L)

            if (selectedClips.isEmpty()) {
                return ArrangedTimeline(
                    targetAudioDurationMs = audioDurationMs,
                    audioStartOffsetMs = audioStartOffsetMs,
                    audioEndOffsetMs = audioEndOffsetMs,
                    totalVideoDurationMs = totalVideoDurationMs,
                    loopStrategy = loopStrategy,
                    singleCycleDurationMs = 0L,
                    fullCyclesCount = 0,
                    remainingMs = 0L,
                    totalSegmentsCount = 0,
                    trimmedSegmentTitle = null,
                    trimmedDurationMs = 0L,
                    originalDurationOfTrimmedClipMs = 0L,
                    segments = emptyList()
                )
            }

            val segments = mutableListOf<TimelineSegment>()
            var segmentIndex = 0

            if (selectedClips.size == 1) {
                // 1 clip: repeat continuously to exact total duration
                val clip = selectedClips[0]
                var cursor = 0L
                while (cursor < totalVideoDurationMs) {
                    val remaining = totalVideoDurationMs - cursor
                    if (remaining >= clip.durationMs) {
                        segments.add(
                            TimelineSegment(
                                index = segmentIndex++,
                                clipId = clip.id,
                                clipTitle = clip.title,
                                clipFilePath = clip.filePath,
                                segmentStartMs = cursor,
                                segmentEndMs = cursor + clip.durationMs,
                                segmentDurationMs = clip.durationMs,
                                sourceClipTrimStartMs = 0L,
                                sourceClipTrimEndMs = clip.durationMs,
                                isFinalTrimmedSegment = false,
                                role = SegmentRole.SINGLE_REPEATING,
                                originalClipDurationMs = clip.durationMs
                            )
                        )
                        cursor += clip.durationMs
                    } else {
                        segments.add(
                            TimelineSegment(
                                index = segmentIndex++,
                                clipId = clip.id,
                                clipTitle = clip.title,
                                clipFilePath = clip.filePath,
                                segmentStartMs = cursor,
                                segmentEndMs = cursor + remaining,
                                segmentDurationMs = remaining,
                                sourceClipTrimStartMs = 0L,
                                sourceClipTrimEndMs = remaining,
                                isFinalTrimmedSegment = true,
                                role = SegmentRole.SINGLE_REPEATING,
                                originalClipDurationMs = clip.durationMs
                            )
                        )
                        cursor += remaining
                    }
                }
            } else if (loopStrategy == LoopStrategy.REPEAT_ALL_CLIPS) {
                // Repeat all clips cyclically in sequence
                var cursor = 0L
                var cycleIndex = 0
                while (cursor < totalVideoDurationMs) {
                    val clip = selectedClips[cycleIndex % selectedClips.size]
                    val remaining = totalVideoDurationMs - cursor
                    if (remaining >= clip.durationMs) {
                        segments.add(
                            TimelineSegment(
                                index = segmentIndex++,
                                clipId = clip.id,
                                clipTitle = clip.title,
                                clipFilePath = clip.filePath,
                                segmentStartMs = cursor,
                                segmentEndMs = cursor + clip.durationMs,
                                segmentDurationMs = clip.durationMs,
                                sourceClipTrimStartMs = 0L,
                                sourceClipTrimEndMs = clip.durationMs,
                                isFinalTrimmedSegment = false,
                                role = SegmentRole.CENTER_LOOP,
                                originalClipDurationMs = clip.durationMs
                            )
                        )
                        cursor += clip.durationMs
                    } else {
                        segments.add(
                            TimelineSegment(
                                index = segmentIndex++,
                                clipId = clip.id,
                                clipTitle = clip.title,
                                clipFilePath = clip.filePath,
                                segmentStartMs = cursor,
                                segmentEndMs = cursor + remaining,
                                segmentDurationMs = remaining,
                                sourceClipTrimStartMs = 0L,
                                sourceClipTrimEndMs = remaining,
                                isFinalTrimmedSegment = true,
                                role = SegmentRole.SECOND_LAST_TRIMMED,
                                originalClipDurationMs = clip.durationMs
                            )
                        )
                        cursor += remaining
                    }
                    cycleIndex++
                }
            } else if (loopStrategy == LoopStrategy.REPEAT_CUSTOM_CLIP && customRepeatClipId != null) {
                // Repeat specific custom clip to fill remaining time
                val repeatClip = selectedClips.find { it.id == customRepeatClipId } ?: selectedClips.first()
                val otherClips = selectedClips.filter { it.id != repeatClip.id }
                val firstClip = if (otherClips.isNotEmpty()) otherClips.first() else repeatClip
                val lastClip = if (otherClips.size > 1) otherClips.last() else repeatClip

                if (totalVideoDurationMs <= firstClip.durationMs) {
                    segments.add(
                        TimelineSegment(
                            index = segmentIndex++,
                            clipId = firstClip.id,
                            clipTitle = firstClip.title,
                            clipFilePath = firstClip.filePath,
                            segmentStartMs = 0L,
                            segmentEndMs = totalVideoDurationMs,
                            segmentDurationMs = totalVideoDurationMs,
                            sourceClipTrimStartMs = 0L,
                            sourceClipTrimEndMs = totalVideoDurationMs,
                            isFinalTrimmedSegment = true,
                            role = SegmentRole.INTRO_FIRST,
                            originalClipDurationMs = firstClip.durationMs
                        )
                    )
                } else {
                    var cursor = 0L
                    // 1. First clip
                    segments.add(
                        TimelineSegment(
                            index = segmentIndex++,
                            clipId = firstClip.id,
                            clipTitle = firstClip.title,
                            clipFilePath = firstClip.filePath,
                            segmentStartMs = cursor,
                            segmentEndMs = cursor + firstClip.durationMs,
                            segmentDurationMs = firstClip.durationMs,
                            sourceClipTrimStartMs = 0L,
                            sourceClipTrimEndMs = firstClip.durationMs,
                            isFinalTrimmedSegment = false,
                            role = SegmentRole.INTRO_FIRST,
                            originalClipDurationMs = firstClip.durationMs
                        )
                    )
                    cursor += firstClip.durationMs

                    val reservedEnd = if (firstClip.id != lastClip.id) lastClip.durationMs else 0L
                    var middleToFill = (totalVideoDurationMs - cursor - reservedEnd).coerceAtLeast(0L)

                    while (middleToFill > 0) {
                        if (middleToFill > repeatClip.durationMs) {
                            segments.add(
                                TimelineSegment(
                                    index = segmentIndex++,
                                    clipId = repeatClip.id,
                                    clipTitle = repeatClip.title,
                                    clipFilePath = repeatClip.filePath,
                                    segmentStartMs = cursor,
                                    segmentEndMs = cursor + repeatClip.durationMs,
                                    segmentDurationMs = repeatClip.durationMs,
                                    sourceClipTrimStartMs = 0L,
                                    sourceClipTrimEndMs = repeatClip.durationMs,
                                    isFinalTrimmedSegment = false,
                                    role = SegmentRole.CUSTOM_LOOP_SEGMENT,
                                    originalClipDurationMs = repeatClip.durationMs
                                )
                            )
                            cursor += repeatClip.durationMs
                            middleToFill -= repeatClip.durationMs
                        } else {
                            segments.add(
                                TimelineSegment(
                                    index = segmentIndex++,
                                    clipId = repeatClip.id,
                                    clipTitle = repeatClip.title,
                                    clipFilePath = repeatClip.filePath,
                                    segmentStartMs = cursor,
                                    segmentEndMs = cursor + middleToFill,
                                    segmentDurationMs = middleToFill,
                                    sourceClipTrimStartMs = 0L,
                                    sourceClipTrimEndMs = middleToFill,
                                    isFinalTrimmedSegment = false,
                                    role = SegmentRole.SECOND_LAST_TRIMMED,
                                    originalClipDurationMs = repeatClip.durationMs
                                )
                            )
                            cursor += middleToFill
                            middleToFill = 0L
                        }
                    }

                    if (reservedEnd > 0 && cursor < totalVideoDurationMs) {
                        val finalRem = totalVideoDurationMs - cursor
                        segments.add(
                            TimelineSegment(
                                index = segmentIndex++,
                                clipId = lastClip.id,
                                clipTitle = lastClip.title,
                                clipFilePath = lastClip.filePath,
                                segmentStartMs = cursor,
                                segmentEndMs = cursor + finalRem,
                                segmentDurationMs = finalRem,
                                sourceClipTrimStartMs = 0L,
                                sourceClipTrimEndMs = finalRem,
                                isFinalTrimmedSegment = finalRem < lastClip.durationMs,
                                role = SegmentRole.OUTRO_LAST,
                                originalClipDurationMs = lastClip.durationMs
                            )
                        )
                    }
                }
            } else {
                // Default: CENTER_CLIP_LOOP (Intro first, Outro last, Center clips repeat with second-to-last trimmed)
                val introClip = selectedClips.first()
                val outroClip = selectedClips.last()
                val centerClips = if (selectedClips.size > 2) {
                    selectedClips.subList(1, selectedClips.size - 1)
                } else {
                    listOf(introClip)
                }

                if (totalVideoDurationMs <= introClip.durationMs) {
                    segments.add(
                        TimelineSegment(
                            index = segmentIndex++,
                            clipId = introClip.id,
                            clipTitle = introClip.title,
                            clipFilePath = introClip.filePath,
                            segmentStartMs = 0L,
                            segmentEndMs = totalVideoDurationMs,
                            segmentDurationMs = totalVideoDurationMs,
                            sourceClipTrimStartMs = 0L,
                            sourceClipTrimEndMs = totalVideoDurationMs,
                            isFinalTrimmedSegment = true,
                            role = SegmentRole.INTRO_FIRST,
                            originalClipDurationMs = introClip.durationMs
                        )
                    )
                } else if (totalVideoDurationMs <= introClip.durationMs + outroClip.durationMs) {
                    segments.add(
                        TimelineSegment(
                            index = segmentIndex++,
                            clipId = introClip.id,
                            clipTitle = introClip.title,
                            clipFilePath = introClip.filePath,
                            segmentStartMs = 0L,
                            segmentEndMs = introClip.durationMs,
                            segmentDurationMs = introClip.durationMs,
                            sourceClipTrimStartMs = 0L,
                            sourceClipTrimEndMs = introClip.durationMs,
                            isFinalTrimmedSegment = false,
                            role = SegmentRole.INTRO_FIRST,
                            originalClipDurationMs = introClip.durationMs
                        )
                    )
                    val remaining = totalVideoDurationMs - introClip.durationMs
                    segments.add(
                        TimelineSegment(
                            index = segmentIndex++,
                            clipId = outroClip.id,
                            clipTitle = outroClip.title,
                            clipFilePath = outroClip.filePath,
                            segmentStartMs = introClip.durationMs,
                            segmentEndMs = totalVideoDurationMs,
                            segmentDurationMs = remaining,
                            sourceClipTrimStartMs = 0L,
                            sourceClipTrimEndMs = remaining,
                            isFinalTrimmedSegment = true,
                            role = SegmentRole.OUTRO_LAST,
                            originalClipDurationMs = outroClip.durationMs
                        )
                    )
                } else {
                    var cursor = 0L

                    // 1. Intro clip played ONCE
                    segments.add(
                        TimelineSegment(
                            index = segmentIndex++,
                            clipId = introClip.id,
                            clipTitle = introClip.title,
                            clipFilePath = introClip.filePath,
                            segmentStartMs = cursor,
                            segmentEndMs = cursor + introClip.durationMs,
                            segmentDurationMs = introClip.durationMs,
                            sourceClipTrimStartMs = 0L,
                            sourceClipTrimEndMs = introClip.durationMs,
                            isFinalTrimmedSegment = false,
                            role = SegmentRole.INTRO_FIRST,
                            originalClipDurationMs = introClip.durationMs
                        )
                    )
                    cursor += introClip.durationMs

                    // 2. Center clips repeated to fill middle
                    var middleToFill = totalVideoDurationMs - introClip.durationMs - outroClip.durationMs
                    var centerIndex = 0

                    while (middleToFill > 0) {
                        val currentCenterClip = centerClips[centerIndex % centerClips.size]

                        if (middleToFill > currentCenterClip.durationMs) {
                            segments.add(
                                TimelineSegment(
                                    index = segmentIndex++,
                                    clipId = currentCenterClip.id,
                                    clipTitle = currentCenterClip.title,
                                    clipFilePath = currentCenterClip.filePath,
                                    segmentStartMs = cursor,
                                    segmentEndMs = cursor + currentCenterClip.durationMs,
                                    segmentDurationMs = currentCenterClip.durationMs,
                                    sourceClipTrimStartMs = 0L,
                                    sourceClipTrimEndMs = currentCenterClip.durationMs,
                                    isFinalTrimmedSegment = false,
                                    role = SegmentRole.CENTER_LOOP,
                                    originalClipDurationMs = currentCenterClip.durationMs
                                )
                            )
                            cursor += currentCenterClip.durationMs
                            middleToFill -= currentCenterClip.durationMs
                            centerIndex++
                        } else {
                            // Exact trim of SECOND-LAST clip
                            segments.add(
                                TimelineSegment(
                                    index = segmentIndex++,
                                    clipId = currentCenterClip.id,
                                    clipTitle = currentCenterClip.title,
                                    clipFilePath = currentCenterClip.filePath,
                                    segmentStartMs = cursor,
                                    segmentEndMs = cursor + middleToFill,
                                    segmentDurationMs = middleToFill,
                                    sourceClipTrimStartMs = 0L,
                                    sourceClipTrimEndMs = middleToFill,
                                    isFinalTrimmedSegment = false,
                                    role = SegmentRole.SECOND_LAST_TRIMMED,
                                    originalClipDurationMs = currentCenterClip.durationMs
                                )
                            )
                            cursor += middleToFill
                            middleToFill = 0L
                            centerIndex++
                        }
                    }

                    // 3. Outro clip played ONCE at end
                    segments.add(
                        TimelineSegment(
                            index = segmentIndex++,
                            clipId = outroClip.id,
                            clipTitle = outroClip.title,
                            clipFilePath = outroClip.filePath,
                            segmentStartMs = cursor,
                            segmentEndMs = cursor + outroClip.durationMs,
                            segmentDurationMs = outroClip.durationMs,
                            sourceClipTrimStartMs = 0L,
                            sourceClipTrimEndMs = outroClip.durationMs,
                            isFinalTrimmedSegment = false,
                            role = SegmentRole.OUTRO_LAST,
                            originalClipDurationMs = outroClip.durationMs
                        )
                    )
                }
            }

            val trimmedSegment = segments.find { it.role == SegmentRole.SECOND_LAST_TRIMMED || it.isFinalTrimmedSegment }
            val singleCycleMs = selectedClips.sumOf { it.durationMs }.coerceAtLeast(1000L)
            val fullCycles = (totalVideoDurationMs / singleCycleMs).toInt()
            val remainingMs = totalVideoDurationMs % singleCycleMs

            return ArrangedTimeline(
                targetAudioDurationMs = audioDurationMs,
                audioStartOffsetMs = audioStartOffsetMs,
                audioEndOffsetMs = audioEndOffsetMs,
                totalVideoDurationMs = totalVideoDurationMs,
                loopStrategy = loopStrategy,
                singleCycleDurationMs = singleCycleMs,
                fullCyclesCount = fullCycles,
                remainingMs = remainingMs,
                totalSegmentsCount = segments.size,
                trimmedSegmentTitle = trimmedSegment?.clipTitle,
                trimmedDurationMs = trimmedSegment?.segmentDurationMs ?: 0L,
                originalDurationOfTrimmedClipMs = trimmedSegment?.originalClipDurationMs ?: 0L,
                segments = segments
            )
        }

        fun formatDuration(ms: Long): String {
            val totalSec = ms / 1000
            val hours = totalSec / 3600
            val min = (totalSec % 3600) / 60
            val sec = totalSec % 60
            return if (hours > 0) {
                String.format("%02d:%02d:%02d", hours, min, sec)
            } else {
                String.format("%02d:%02d", min, sec)
            }
        }
    }
}
