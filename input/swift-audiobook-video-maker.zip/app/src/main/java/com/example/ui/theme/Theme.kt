package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = AmberAccent,
    onPrimary = Color.Black,
    primaryContainer = AmberContainer,
    onPrimaryContainer = AmberOnContainer,
    secondary = SkyAccent,
    onSecondary = Color.Black,
    secondaryContainer = SkyContainer,
    onSecondaryContainer = Color.White,
    tertiary = GreenSuccess,
    onTertiary = Color.Black,
    tertiaryContainer = GreenContainer,
    onTertiaryContainer = Color.White,
    background = SlateDarkBackground,
    onBackground = TextPrimary,
    surface = SlateDarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = SlateCardSurface,
    onSurfaceVariant = TextSecondary,
    outline = SlateBorder,
    outlineVariant = SlateDivider,
    error = RedError,
    onError = Color.White,
    errorContainer = RedContainer,
    onErrorContainer = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
