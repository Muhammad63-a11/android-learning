package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val SlateDarkBackground = Color(0xFF090D13)
val SlateDarkSurface = Color(0xFF131A24)
val SlateCardSurface = Color(0xFF1B2432)
val SlateBorder = Color(0xFF2B384B)
val SlateDivider = Color(0xFF1E2838)

val AmberAccent = Color(0xFFFFA14A)
val AmberAccentDark = Color(0xFFD97706)
val AmberAccentLight = Color(0xFFFFBE76)
val AmberContainer = Color(0xFF382310)
val AmberOnContainer = Color(0xFFFFD8B3)

val SkyAccent = Color(0xFF38BDF8)
val SkyContainer = Color(0xFF0C3048)

val GreenSuccess = Color(0xFF10B981)
val GreenContainer = Color(0xFF063622)

val RedError = Color(0xFFEF4444)
val RedContainer = Color(0xFF3B1212)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
