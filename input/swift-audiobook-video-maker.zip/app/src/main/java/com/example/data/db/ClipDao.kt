package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ClipDao {
    @Query("SELECT * FROM clips ORDER BY createdAt DESC")
    fun getAllClips(): Flow<List<ClipEntity>>

    @Query("SELECT * FROM clips WHERE id = :id LIMIT 1")
    suspend fun getClipById(id: String): ClipEntity?

    @Query("SELECT * FROM clips WHERE id IN (:ids)")
    suspend fun getClipsByIds(ids: List<String>): List<ClipEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClip(clip: ClipEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertClips(clips: List<ClipEntity>)

    @Query("UPDATE clips SET title = :newTitle WHERE id = :id")
    suspend fun updateClipTitle(id: String, newTitle: String)

    @Query("DELETE FROM clips WHERE id = :id")
    suspend fun deleteClipById(id: String)

    @Query("SELECT COUNT(*) FROM clips")
    fun getClipCount(): Flow<Int>
}
