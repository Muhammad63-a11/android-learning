package com.example.ui.components

import android.media.MediaPlayer
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Forward5
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay5
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ArrangedTimeline
import com.example.model.AudioItem
import com.example.model.SegmentRole
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.AmberContainer
import com.example.ui.theme.GreenSuccess
import com.example.ui.theme.SkyAccent
import com.example.ui.theme.SlateBorder
import com.example.ui.theme.SlateCardSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.delay
import java.io.File

@Composable
fun EditorLivePlayer(
    timeline: ArrangedTimeline?,
    audioItem: AudioItem?,
    modifier: Modifier = Modifier,
    onSegmentChanged: ((Int) -> Unit)? = null
) {
    val context = LocalContext.current

    var currentPositionMs by remember { mutableLongStateOf(0L) }
    var isPlaying by remember { mutableStateOf(false) }
    var isUserScrubbing by remember { mutableStateOf(false) }
    var scrubSliderValue by remember { mutableFloatStateOf(0f) }

    val targetDurationMs = timeline?.targetAudioDurationMs ?: 60000L
    val activeSegment = timeline?.getSegmentAtTime(currentPositionMs)

    var audioPlayer by remember { mutableStateOf<MediaPlayer?>(null) }

    // Synchronize Audio Player
    DisposableEffect(audioItem?.filePath) {
        val audioFile = audioItem?.filePath?.let { File(it) }
        var player: MediaPlayer? = null
        if (audioFile != null && audioFile.exists()) {
            try {
                player = MediaPlayer().apply {
                    setDataSource(audioFile.absolutePath)
                    prepare()
                    val vol = audioItem.volume.coerceIn(0f, 1f)
                    setVolume(vol, vol)
                }
                audioPlayer = player
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        onDispose {
            player?.stop()
            player?.release()
            audioPlayer = null
        }
    }

    // Playhead ticker coroutine
    LaunchedEffect(isPlaying, targetDurationMs) {
        while (isPlaying) {
            delay(100)
            if (!isUserScrubbing) {
                val newPos = currentPositionMs + 100
                if (newPos >= targetDurationMs) {
                    currentPositionMs = 0L
                    audioPlayer?.seekTo(0)
                    audioPlayer?.start()
                } else {
                    currentPositionMs = newPos
                }
            }
        }
    }

    // Notify parent of active segment changes
    LaunchedEffect(activeSegment?.index) {
        activeSegment?.index?.let { onSegmentChanged?.invoke(it) }
    }

    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        color = SlateCardSurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Live Video Display Box
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color.Black),
                contentAlignment = Alignment.Center
            ) {
                if (activeSegment != null) {
                    VideoPlayerView(
                        videoPath = activeSegment.clipFilePath,
                        modifier = Modifier.fillMaxSize(),
                        isLooping = true
                    )
                } else {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "No Video Clips in Timeline",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextMuted
                        )
                    }
                }

                // Top Overlay Pill: Segment Information & Role
                if (activeSegment != null) {
                    Row(
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(10.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xCC0B111A))
                            .border(1.dp, Color(0x66FFFFFF), RoundedCornerShape(8.dp))
                            .padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val roleColor = when (activeSegment.role) {
                            SegmentRole.INTRO_FIRST -> SkyAccent
                            SegmentRole.SECOND_LAST_TRIMMED -> AmberAccent
                            SegmentRole.OUTRO_LAST -> GreenSuccess
                            else -> TextSecondary
                        }

                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(roleColor)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "#${activeSegment.index + 1}: ${activeSegment.clipTitle} • ${activeSegment.roleLabel}",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            color = TextPrimary,
                            maxLines = 1
                        )
                    }
                }

                // Play / Pause big central toggle button
                if (!isPlaying) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.Center)
                            .size(54.dp)
                            .clip(CircleShape)
                            .background(AmberContainer.copy(alpha = 0.9f))
                            .border(2.dp, AmberAccent, CircleShape)
                            .clickable {
                                isPlaying = true
                                audioPlayer?.seekTo((currentPositionMs % (audioPlayer?.duration ?: 1)).toInt())
                                audioPlayer?.start()
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Play",
                            tint = AmberAccent,
                            modifier = Modifier.size(32.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Scrubber Slider
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = formatMs(currentPositionMs),
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = AmberAccent
                )

                Slider(
                    value = if (isUserScrubbing) scrubSliderValue else (currentPositionMs.toFloat() / targetDurationMs.coerceAtLeast(1L).toFloat()).coerceIn(0f, 1f),
                    onValueChange = { frac ->
                        isUserScrubbing = true
                        scrubSliderValue = frac
                        val targetMs = (frac * targetDurationMs).toLong()
                        currentPositionMs = targetMs
                    },
                    onValueChangeFinished = {
                        isUserScrubbing = false
                        val targetMs = (scrubSliderValue * targetDurationMs).toLong()
                        currentPositionMs = targetMs
                        audioPlayer?.let { p ->
                            val audioDur = p.duration.coerceAtLeast(1)
                            p.seekTo((targetMs % audioDur).toInt())
                            if (isPlaying) p.start()
                        }
                    },
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 8.dp),
                    colors = SliderDefaults.colors(
                        thumbColor = AmberAccent,
                        activeTrackColor = AmberAccent,
                        inactiveTrackColor = SlateBorder
                    )
                )

                Text(
                    text = formatMs(targetDurationMs),
                    style = MaterialTheme.typography.labelSmall,
                    color = TextSecondary
                )
            }

            // Controls Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.VolumeUp,
                        contentDescription = null,
                        tint = if (audioItem != null) GreenSuccess else TextMuted,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = audioItem?.title?.take(22) ?: "No Audio Track",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (audioItem != null) TextSecondary else TextMuted,
                        maxLines = 1
                    )
                }

                Row(
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = {
                            currentPositionMs = (currentPositionMs - 5000L).coerceAtLeast(0L)
                            audioPlayer?.seekTo((currentPositionMs % (audioPlayer?.duration ?: 1)).toInt())
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Replay5,
                            contentDescription = "Back 5s",
                            tint = TextPrimary
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(AmberAccent)
                            .clickable {
                                isPlaying = !isPlaying
                                if (isPlaying) {
                                    audioPlayer?.seekTo((currentPositionMs % (audioPlayer?.duration ?: 1)).toInt())
                                    audioPlayer?.start()
                                } else {
                                    audioPlayer?.pause()
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                            contentDescription = if (isPlaying) "Pause" else "Play",
                            tint = Color.Black,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    IconButton(
                        onClick = {
                            currentPositionMs = (currentPositionMs + 5000L).coerceAtMost(targetDurationMs)
                            audioPlayer?.seekTo((currentPositionMs % (audioPlayer?.duration ?: 1)).toInt())
                        }
                    ) {
                        Icon(
                            imageVector = Icons.Default.Forward5,
                            contentDescription = "Forward 5s",
                            tint = TextPrimary
                        )
                    }
                }
            }
        }
    }
}

private fun formatMs(ms: Long): String {
    val totalSec = ms / 1000
    val min = totalSec / 60
    val sec = totalSec % 60
    return String.format("%02d:%02d", min, sec)
}
