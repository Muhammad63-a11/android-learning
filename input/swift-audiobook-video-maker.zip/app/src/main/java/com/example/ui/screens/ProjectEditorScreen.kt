package com.example.ui.screens

import android.content.Context
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Collections
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.SwapVert
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.UploadFile
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.ClipItem
import com.example.model.LoopStrategy
import com.example.ui.components.ArrangementVisualizer
import com.example.ui.components.EditorLivePlayer
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.AmberContainer
import com.example.ui.theme.GreenSuccess
import com.example.ui.theme.SkyAccent
import com.example.ui.theme.SlateBorder
import com.example.ui.theme.SlateCardSurface
import com.example.ui.theme.SlateDarkBackground
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.AudiobookViewModel
import com.example.ui.viewmodel.SubScreen

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ProjectEditorScreen(
    viewModel: AudiobookViewModel,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val projectTitle by viewModel.projectTitle.collectAsState()
    val allClips by viewModel.allClips.collectAsState()
    val selectedClipIds by viewModel.selectedClipIds.collectAsState()
    val selectedAudio by viewModel.selectedAudio.collectAsState()
    val arrangedTimeline by viewModel.arrangedTimeline.collectAsState()
    val isPipEnabled by viewModel.isPipEnabled.collectAsState()

    val loopStrategy by viewModel.loopStrategy.collectAsState()
    val customRepeatClipId by viewModel.customRepeatClipId.collectAsState()
    val audioStartOffsetSec by viewModel.audioStartOffsetSec.collectAsState()
    val audioEndOffsetSec by viewModel.audioEndOffsetSec.collectAsState()
    val audioVolume by viewModel.audioVolume.collectAsState()
    val videoVolume by viewModel.videoVolume.collectAsState()

    val scrollState = rememberScrollState()

    var showClipPickerModal by remember { mutableStateOf(false) }
    var heldClipIndexForSwap by remember { mutableStateOf<Int?>(null) }

    val clipMap = remember(allClips) { allClips.associateBy { it.id } }
    val orderedSelectedClips = remember(selectedClipIds, clipMap) {
        selectedClipIds.mapNotNull { clipMap[it] }
    }

    // Video Gallery Picker
    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let { viewModel.importPremadeVideo(it, context) }
    }

    // Audio Picker
    val audioPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let { viewModel.importAudioFile(it, context) }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SlateDarkBackground)
            .verticalScroll(scrollState)
            .padding(horizontal = 18.dp, vertical = 16.dp)
    ) {
        // Top App Bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = TextPrimary
                    )
                }
                Spacer(modifier = Modifier.width(6.dp))
                Column {
                    Text(
                        text = "Audiobook Video Editor",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = TextPrimary
                    )
                    Text(
                        text = "Pure C-Stream Copy • Zero Quality Loss",
                        style = MaterialTheme.typography.labelSmall,
                        color = AmberAccent
                    )
                }
            }

            // Quick Fast Export CTA in App Bar
            Button(
                onClick = { viewModel.startFastExport(context) },
                enabled = orderedSelectedClips.isNotEmpty(),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AmberAccent, contentColor = Color.Black),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                modifier = Modifier.testTag("appbar_fast_export_button")
            ) {
                Icon(
                    imageVector = Icons.Default.RocketLaunch,
                    contentDescription = null,
                    tint = Color.Black,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "Export",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Project Title
        OutlinedTextField(
            value = projectTitle,
            onValueChange = { viewModel.updateProjectTitle(it) },
            label = { Text("Project Title") },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("project_name_input"),
            shape = RoundedCornerShape(14.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary,
                focusedContainerColor = SlateCardSurface,
                unfocusedContainerColor = SlateCardSurface,
                focusedBorderColor = AmberAccent,
                unfocusedBorderColor = SlateBorder
            ),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(18.dp))

        // IN-EDITOR LIVE PREVIEW PLAYER
        Text(
            text = "LIVE VIDEO & AUDIO PREVIEW",
            style = MaterialTheme.typography.labelSmall,
            letterSpacing = 1.sp,
            fontWeight = FontWeight.Bold,
            color = TextMuted
        )

        Spacer(modifier = Modifier.height(6.dp))

        EditorLivePlayer(
            timeline = arrangedTimeline,
            audioItem = selectedAudio,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(20.dp))

        // STEP 1: SELECTED CLIPS & CLICK-AND-HOLD SWAP
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "1. ORDERED CLIPS (${orderedSelectedClips.size})",
                    style = MaterialTheme.typography.labelSmall,
                    letterSpacing = 1.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextMuted
                )
                Text(
                    text = "Saved in library • Click & hold to swap order",
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 10.sp,
                    color = SkyAccent
                )
            }

            Row {
                TextButton(
                    onClick = { videoPickerLauncher.launch("video/*") },
                    modifier = Modifier.testTag("pick_gallery_video_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Collections,
                        contentDescription = null,
                        tint = GreenSuccess,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add from Phone", color = GreenSuccess, fontSize = 12.sp)
                }

                TextButton(
                    onClick = { showClipPickerModal = true },
                    modifier = Modifier.testTag("add_clips_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = null,
                        tint = AmberAccent,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Select Clips", color = AmberAccent, fontSize = 12.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Swap Banner when click-and-hold is active
        AnimatedVisibility(
            visible = heldClipIndexForSwap != null,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            val heldIdx = heldClipIndexForSwap
            val heldTitle = if (heldIdx != null && heldIdx in orderedSelectedClips.indices) orderedSelectedClips[heldIdx].title else ""
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 10.dp),
                shape = RoundedCornerShape(12.dp),
                color = Color(0xFF332008),
                border = androidx.compose.foundation.BorderStroke(1.dp, AmberAccent)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.SwapVert,
                            contentDescription = null,
                            tint = AmberAccent,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Swapping \"$heldTitle\". Tap another clip to swap!",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = AmberAccent
                        )
                    }

                    TextButton(onClick = { heldClipIndexForSwap = null }) {
                        Text("Cancel", color = TextMuted, fontSize = 11.sp)
                    }
                }
            }
        }

        if (orderedSelectedClips.isEmpty()) {
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .clickable { showClipPickerModal = true }
                    .testTag("empty_clips_placeholder"),
                color = SlateCardSurface,
                border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.VideoLibrary,
                        contentDescription = null,
                        tint = AmberAccent,
                        modifier = Modifier.size(36.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "No Clips Selected",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Tap to choose videos from your library or phone",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }
        } else {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                orderedSelectedClips.forEachIndexed { index, clip ->
                    val isBeingHeld = heldClipIndexForSwap == index
                    val isIntro = index == 0
                    val isOutro = index == orderedSelectedClips.size - 1 && orderedSelectedClips.size > 1
                    val isCenter = !isIntro && !isOutro

                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .combinedClickable(
                                onClick = {
                                    if (heldClipIndexForSwap != null) {
                                        viewModel.swapClips(heldClipIndexForSwap!!, index)
                                        heldClipIndexForSwap = null
                                    }
                                },
                                onLongClick = {
                                    heldClipIndexForSwap = if (heldClipIndexForSwap == index) null else index
                                }
                            )
                            .testTag("selected_clip_item_$index"),
                        color = if (isBeingHeld) Color(0xFF332008) else SlateCardSurface,
                        border = androidx.compose.foundation.BorderStroke(
                            if (isBeingHeld) 2.dp else 1.dp,
                            if (isBeingHeld) AmberAccent else SlateBorder
                        )
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (isBeingHeld) AmberAccent else Color(0xFF1E293B)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "#${index + 1}",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isBeingHeld) Color.Black else AmberAccent
                                    )
                                }

                                Spacer(modifier = Modifier.width(10.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = clip.title,
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimary,
                                        maxLines = 1
                                    )
                                    val roleText = when {
                                        loopStrategy == LoopStrategy.REPEAT_ALL_CLIPS -> "Repeats in full cycle"
                                        loopStrategy == LoopStrategy.REPEAT_CUSTOM_CLIP && customRepeatClipId == clip.id -> "Custom looping clip"
                                        isIntro -> "Intro (Plays 1x at start)"
                                        isOutro -> "Outro (Plays 1x at end)"
                                        else -> "Center clip (Repeats to fill length)"
                                    }
                                    Text(
                                        text = "${clip.durationFormatted} • $roleText",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextSecondary
                                    )
                                }

                                // Move Buttons
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(
                                        onClick = { viewModel.moveClipUp(index) },
                                        enabled = index > 0,
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.ArrowUpward,
                                            contentDescription = "Move Up",
                                            tint = if (index > 0) TextPrimary else TextMuted,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }

                                    IconButton(
                                        onClick = { viewModel.moveClipDown(index) },
                                        enabled = index < orderedSelectedClips.size - 1,
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.ArrowDownward,
                                            contentDescription = "Move Down",
                                            tint = if (index < orderedSelectedClips.size - 1) TextPrimary else TextMuted,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }

                                    IconButton(
                                        onClick = { viewModel.removeClipFromSelectionAt(index) },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Delete,
                                            contentDescription = "Remove",
                                            tint = Color(0xFFEF4444),
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(22.dp))

        // STEP 2: VIDEO LOOPING & REPEATING STRATEGY
        Text(
            text = "2. VIDEO LOOPING STRATEGY",
            style = MaterialTheme.typography.labelSmall,
            letterSpacing = 1.sp,
            fontWeight = FontWeight.Bold,
            color = TextMuted
        )

        Spacer(modifier = Modifier.height(8.dp))

        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            color = SlateCardSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                // Strategy 1: Center Clip Loop
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { viewModel.setLoopStrategy(LoopStrategy.CENTER_CLIP_LOOP) }
                        .padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = loopStrategy == LoopStrategy.CENTER_CLIP_LOOP,
                        onClick = { viewModel.setLoopStrategy(LoopStrategy.CENTER_CLIP_LOOP) },
                        colors = RadioButtonDefaults.colors(selectedColor = AmberAccent)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Preserve 1st & Last Clip (Center Loop)",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = "1st clip plays at start, last clip at end. Center clips repeat, and 2nd-to-last clip is trimmed to fit exact length.",
                            style = MaterialTheme.typography.bodySmall,
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Strategy 2: Repeat All Clips
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { viewModel.setLoopStrategy(LoopStrategy.REPEAT_ALL_CLIPS) }
                        .padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = loopStrategy == LoopStrategy.REPEAT_ALL_CLIPS,
                        onClick = { viewModel.setLoopStrategy(LoopStrategy.REPEAT_ALL_CLIPS) },
                        colors = RadioButtonDefaults.colors(selectedColor = AmberAccent)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Repeat All Clips in Sequence",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = "Cycles through all selected clips in full order until total audio length is matched, trimming the final clip.",
                            style = MaterialTheme.typography.bodySmall,
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Strategy 3: Repeat Custom Clip
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .clickable { viewModel.setLoopStrategy(LoopStrategy.REPEAT_CUSTOM_CLIP) }
                        .padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(
                        selected = loopStrategy == LoopStrategy.REPEAT_CUSTOM_CLIP,
                        onClick = { viewModel.setLoopStrategy(LoopStrategy.REPEAT_CUSTOM_CLIP) },
                        colors = RadioButtonDefaults.colors(selectedColor = AmberAccent)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Repeat Custom Specific Clip",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = "Plays intro & outro clips while repeating your chosen clip repeatedly to reach the exact video length.",
                            style = MaterialTheme.typography.bodySmall,
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                }

                // If Custom Clip strategy is active, let user pick the repeating clip
                if (loopStrategy == LoopStrategy.REPEAT_CUSTOM_CLIP && orderedSelectedClips.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "Select Which Clip Repeats:",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = SkyAccent
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        orderedSelectedClips.forEachIndexed { i, c ->
                            val isSelected = (customRepeatClipId == c.id) || (customRepeatClipId == null && i == 0)
                            FilterChip(
                                selected = isSelected,
                                onClick = { viewModel.setCustomRepeatClipId(c.id) },
                                label = { Text("#${i + 1} ${c.title.take(10)}") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = AmberContainer,
                                    selectedLabelColor = AmberAccent
                                )
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(22.dp))

        // STEP 3: NARRATION AUDIO & AUDIO TIMING OFFSETS
        Text(
            text = "3. NARRATION AUDIO & TIMING OFFSETS",
            style = MaterialTheme.typography.labelSmall,
            letterSpacing = 1.sp,
            fontWeight = FontWeight.Bold,
            color = TextMuted
        )

        Spacer(modifier = Modifier.height(8.dp))

        if (selectedAudio == null) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .clickable { audioPickerLauncher.launch("audio/*") }
                        .testTag("import_audio_button"),
                    color = SlateCardSurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.UploadFile,
                            contentDescription = null,
                            tint = SkyAccent,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Import Audio",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "MP3, WAV, M4A, AAC",
                            style = MaterialTheme.typography.bodySmall,
                            fontSize = 10.sp,
                            color = TextSecondary
                        )
                    }
                }

                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .clickable { viewModel.openSubScreen(SubScreen.EDGE_TTS) }
                        .testTag("generate_tts_card_button"),
                    color = Color(0xFF2A1F13),
                    border = androidx.compose.foundation.BorderStroke(1.dp, AmberAccent.copy(alpha = 0.5f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.RecordVoiceOver,
                            contentDescription = null,
                            tint = AmberAccent,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Generate Voice",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = AmberAccent
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Free AI Voice Narration",
                            style = MaterialTheme.typography.bodySmall,
                            fontSize = 10.sp,
                            color = TextSecondary
                        )
                    }
                }
            }
        } else {
            val audio = selectedAudio!!
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                color = SlateCardSurface,
                border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(if (audio.isTtsGenerated) AmberContainer else Color(0xFF0C3048)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (audio.isTtsGenerated) Icons.Default.RecordVoiceOver else Icons.Default.Audiotrack,
                                    contentDescription = null,
                                    tint = if (audio.isTtsGenerated) AmberAccent else SkyAccent,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = audio.title,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary,
                                    maxLines = 1
                                )
                                Text(
                                    text = "Duration: ${audio.durationFormatted}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = GreenSuccess
                                )
                            }
                        }

                        IconButton(onClick = { viewModel.removeAudio() }) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Remove Audio",
                                tint = TextMuted
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Audio Start Offset (Pre-roll) Slider & Chips
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Timer,
                                contentDescription = null,
                                tint = AmberAccent,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Audio Start Point (Delay)",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        }
                        Text(
                            text = "${audioStartOffsetSec.toInt()} sec",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = AmberAccent
                        )
                    }

                    Text(
                        text = "Audio starts ${audioStartOffsetSec.toInt()}s after video starts",
                        style = MaterialTheme.typography.bodySmall,
                        fontSize = 11.sp,
                        color = TextSecondary
                    )

                    Slider(
                        value = audioStartOffsetSec,
                        onValueChange = { viewModel.setAudioStartOffsetSec(it) },
                        valueRange = 0f..60f,
                        colors = SliderDefaults.colors(
                            thumbColor = AmberAccent,
                            activeTrackColor = AmberAccent,
                            inactiveTrackColor = Color(0xFF283648)
                        )
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(0f, 3f, 5f, 8f, 10f, 15f, 30f).forEach { sec ->
                            FilterChip(
                                selected = audioStartOffsetSec == sec,
                                onClick = { viewModel.setAudioStartOffsetSec(sec) },
                                label = { Text("${sec.toInt()}s", fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = AmberContainer,
                                    selectedLabelColor = AmberAccent
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Audio End Offset (Post-roll) Slider & Chips
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Timer,
                                contentDescription = null,
                                tint = SkyAccent,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Video End Padding (After Audio)",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        }
                        Text(
                            text = "${audioEndOffsetSec.toInt()} sec",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = SkyAccent
                        )
                    }

                    Text(
                        text = "Video continues for ${audioEndOffsetSec.toInt()}s after audio ends",
                        style = MaterialTheme.typography.bodySmall,
                        fontSize = 11.sp,
                        color = TextSecondary
                    )

                    Slider(
                        value = audioEndOffsetSec,
                        onValueChange = { viewModel.setAudioEndOffsetSec(it) },
                        valueRange = 0f..60f,
                        colors = SliderDefaults.colors(
                            thumbColor = SkyAccent,
                            activeTrackColor = SkyAccent,
                            inactiveTrackColor = Color(0xFF283648)
                        )
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(0f, 3f, 5f, 8f, 10f, 15f, 30f).forEach { sec ->
                            FilterChip(
                                selected = audioEndOffsetSec == sec,
                                onClick = { viewModel.setAudioEndOffsetSec(sec) },
                                label = { Text("${sec.toInt()}s", fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = Color(0xFF0D304B),
                                    selectedLabelColor = SkyAccent
                                )
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(22.dp))

        // STEP 4: VOLUME CONTROLS (AUDIO & VIDEO)
        Text(
            text = "4. AUDIO & VIDEO VOLUME CONTROLS",
            style = MaterialTheme.typography.labelSmall,
            letterSpacing = 1.sp,
            fontWeight = FontWeight.Bold,
            color = TextMuted
        )

        Spacer(modifier = Modifier.height(8.dp))

        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            color = SlateCardSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                // Narration Volume
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                            contentDescription = null,
                            tint = AmberAccent,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Audiobook / Narration Volume",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    }
                    Text(
                        text = "${(audioVolume * 100).toInt()}%",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = AmberAccent
                    )
                }

                Slider(
                    value = audioVolume,
                    onValueChange = { viewModel.setAudioVolume(it) },
                    valueRange = 0f..2.0f,
                    colors = SliderDefaults.colors(
                        thumbColor = AmberAccent,
                        activeTrackColor = AmberAccent,
                        inactiveTrackColor = Color(0xFF283648)
                    )
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(0.5f, 1.0f, 1.25f, 1.5f, 2.0f).forEach { vol ->
                        FilterChip(
                            selected = audioVolume == vol,
                            onClick = { viewModel.setAudioVolume(vol) },
                            label = { Text("${(vol * 100).toInt()}%", fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = AmberContainer,
                                selectedLabelColor = AmberAccent
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Video Clip Audio Volume
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (videoVolume == 0f) Icons.Default.VolumeOff else Icons.AutoMirrored.Filled.VolumeUp,
                            contentDescription = null,
                            tint = if (videoVolume == 0f) TextMuted else GreenSuccess,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Original Video Audio Volume",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    }
                    Text(
                        text = if (videoVolume == 0f) "Muted (0%)" else "${(videoVolume * 100).toInt()}%",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (videoVolume == 0f) TextMuted else GreenSuccess
                    )
                }

                Slider(
                    value = videoVolume,
                    onValueChange = { viewModel.setVideoVolume(it) },
                    valueRange = 0f..1.0f,
                    colors = SliderDefaults.colors(
                        thumbColor = GreenSuccess,
                        activeTrackColor = GreenSuccess,
                        inactiveTrackColor = Color(0xFF283648)
                    )
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(0.0f, 0.2f, 0.5f, 1.0f).forEach { vol ->
                        FilterChip(
                            selected = videoVolume == vol,
                            onClick = { viewModel.setVideoVolume(vol) },
                            label = { Text(if (vol == 0f) "Mute" else "${(vol * 100).toInt()}%", fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Color(0xFF0C3B24),
                                selectedLabelColor = GreenSuccess
                            )
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(22.dp))

        // STEP 5: AUTOMATIC TIMELINE ARRANGEMENT WITH REPEATER
        ArrangementVisualizer(
            timeline = arrangedTimeline,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(22.dp))

        // STEP 6: EXPORT DESTINATION & SPEED
        Text(
            text = "6. PHONE GALLERY & FAST STREAM EXPORT",
            style = MaterialTheme.typography.labelSmall,
            letterSpacing = 1.sp,
            fontWeight = FontWeight.Bold,
            color = TextMuted
        )

        Spacer(modifier = Modifier.height(8.dp))

        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            color = SlateCardSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                // Phone Gallery Info Banner
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF072619))
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Collections,
                        contentDescription = null,
                        tint = GreenSuccess,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Auto-Saved to Phone Gallery (Movies/AudiobookVideos). Pure C-Stream copy exports in seconds with zero lag or hang.",
                        style = MaterialTheme.typography.bodySmall,
                        fontSize = 11.sp,
                        color = GreenSuccess,
                        lineHeight = 15.sp
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Pure Fast Stream Muxing",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = GreenSuccess
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .background(Color(0xFF063622), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = "INSTANT C-STREAM",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Black,
                                    color = GreenSuccess
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Direct bitstream copy avoids re-encoding. 100% loss-free quality.",
                            style = MaterialTheme.typography.bodySmall,
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(26.dp))

        // Big Main CTA Buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            OutlinedButton(
                onClick = { viewModel.openSubScreen(SubScreen.PREVIEW) },
                modifier = Modifier
                    .weight(1f)
                    .height(54.dp)
                    .testTag("full_preview_button"),
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, AmberAccent.copy(alpha = 0.6f)),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = AmberAccent)
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Full Preview",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.Bold
                )
            }

            Button(
                onClick = { viewModel.startFastExport(context) },
                enabled = orderedSelectedClips.isNotEmpty(),
                modifier = Modifier
                    .weight(1.3f)
                    .height(54.dp)
                    .testTag("fast_export_main_button"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = AmberAccent,
                    contentColor = Color.Black
                )
            ) {
                Icon(
                    imageVector = Icons.Default.RocketLaunch,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp),
                    tint = Color.Black
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Start Fast Export",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.Black
                )
            }
        }

        Spacer(modifier = Modifier.height(36.dp))
    }

    // Clip Selection Modal
    if (showClipPickerModal) {
        ClipPickerModal(
            allClips = allClips,
            selectedClipIds = selectedClipIds,
            onToggleClip = { viewModel.toggleClipSelection(it) },
            onImportGalleryVideo = { videoPickerLauncher.launch("video/*") },
            onDismiss = { showClipPickerModal = false }
        )
    }
}

@Composable
private fun ClipPickerModal(
    allClips: List<ClipItem>,
    selectedClipIds: List<String>,
    onToggleClip: (String) -> Unit,
    onImportGalleryVideo: () -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp)),
            color = SlateCardSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Saved Clips Library",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = "${allClips.size} saved clips available",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondary
                        )
                    }

                    Button(
                        onClick = onDismiss,
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = AmberAccent, contentColor = Color.Black)
                    ) {
                        Text("Done", fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Import from gallery CTA inside modal
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { onImportGalleryVideo() },
                    color = Color(0xFF132B25),
                    border = androidx.compose.foundation.BorderStroke(1.dp, GreenSuccess.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Collections,
                            contentDescription = null,
                            tint = GreenSuccess,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "Import Video from Phone",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = GreenSuccess
                            )
                            Text(
                                text = "Saves permanently to your library",
                                style = MaterialTheme.typography.bodySmall,
                                fontSize = 10.sp,
                                color = TextSecondary
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(300.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(allClips) { clip ->
                        val isSelected = selectedClipIds.contains(clip.id)
                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .clickable { onToggleClip(clip.id) },
                            color = if (isSelected) Color(0xFF332008) else Color(0xFF131D2A),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isSelected) AmberAccent else SlateBorder
                            )
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    modifier = Modifier.weight(1f),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(34.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(if (isSelected) AmberAccent else Color(0xFF1E293B)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = if (isSelected) Icons.Default.Check else Icons.Default.Movie,
                                            contentDescription = null,
                                            tint = if (isSelected) Color.Black else TextMuted,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }

                                    Spacer(modifier = Modifier.width(10.dp))

                                    Column {
                                        Text(
                                            text = clip.title,
                                            style = MaterialTheme.typography.bodyMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = TextPrimary,
                                            maxLines = 1
                                        )
                                        Text(
                                            text = "${clip.durationFormatted} • ${clip.width}x${clip.height}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = TextSecondary
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
