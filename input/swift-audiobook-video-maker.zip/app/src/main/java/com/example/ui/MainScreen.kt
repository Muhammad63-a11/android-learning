package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.screens.ClipLibraryScreen
import com.example.ui.screens.CompletedScreen
import com.example.ui.screens.EdgeTtsScreen
import com.example.ui.screens.ExportScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.PreviewScreen
import com.example.ui.screens.ProjectEditorScreen
import com.example.ui.screens.ProjectsListScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.SlateBorder
import com.example.ui.theme.SlateDarkBackground
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.viewmodel.AudiobookViewModel
import com.example.ui.viewmodel.NavigationTab
import com.example.ui.viewmodel.SubScreen

@Composable
fun MainScreen(
    viewModel: AudiobookViewModel,
    modifier: Modifier = Modifier
) {
    val currentTab by viewModel.currentTab.collectAsState()
    val currentSubScreen by viewModel.currentSubScreen.collectAsState()

    // Handle Android system back button
    BackHandler(enabled = currentSubScreen != SubScreen.NONE) {
        viewModel.navigateBack()
    }

    val showBottomBar = currentSubScreen == SubScreen.NONE

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = SlateDarkBackground,
        bottomBar = {
            if (showBottomBar) {
                NavigationBar(
                    containerColor = Color(0xFF0F1722),
                    tonalElevation = 8.dp,
                    modifier = Modifier.testTag("main_bottom_nav")
                ) {
                    NavigationBarItem(
                        selected = currentTab == NavigationTab.HOME,
                        onClick = { viewModel.setTab(NavigationTab.HOME) },
                        icon = {
                            Icon(
                                imageVector = Icons.Default.Home,
                                contentDescription = "Home",
                                modifier = Modifier.size(24.dp)
                            )
                        },
                        label = { Text("Home", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = AmberAccent,
                            selectedTextColor = AmberAccent,
                            unselectedIconColor = TextMuted,
                            unselectedTextColor = TextMuted,
                            indicatorColor = Color(0xFF1E2838)
                        ),
                        modifier = Modifier.testTag("nav_home")
                    )

                    NavigationBarItem(
                        selected = currentTab == NavigationTab.LIBRARY,
                        onClick = { viewModel.setTab(NavigationTab.LIBRARY) },
                        icon = {
                            Icon(
                                imageVector = Icons.Default.Movie,
                                contentDescription = "Clips",
                                modifier = Modifier.size(24.dp)
                            )
                        },
                        label = { Text("Clips", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = AmberAccent,
                            selectedTextColor = AmberAccent,
                            unselectedIconColor = TextMuted,
                            unselectedTextColor = TextMuted,
                            indicatorColor = Color(0xFF1E2838)
                        ),
                        modifier = Modifier.testTag("nav_clips")
                    )

                    NavigationBarItem(
                        selected = currentTab == NavigationTab.CREATE,
                        onClick = {
                            viewModel.createNewProject()
                        },
                        icon = {
                            Icon(
                                imageVector = Icons.Default.AddCircle,
                                contentDescription = "Create",
                                tint = AmberAccent,
                                modifier = Modifier.size(28.dp)
                            )
                        },
                        label = { Text("Create", fontSize = 11.sp, color = AmberAccent) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = AmberAccent,
                            selectedTextColor = AmberAccent,
                            unselectedIconColor = AmberAccent,
                            unselectedTextColor = AmberAccent,
                            indicatorColor = Color(0xFF2E2418)
                        ),
                        modifier = Modifier.testTag("nav_create")
                    )

                    NavigationBarItem(
                        selected = currentTab == NavigationTab.SETTINGS,
                        onClick = { viewModel.setTab(NavigationTab.SETTINGS) },
                        icon = {
                            Icon(
                                imageVector = Icons.Default.Tune,
                                contentDescription = "Settings",
                                modifier = Modifier.size(24.dp)
                            )
                        },
                        label = { Text("Settings", fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = AmberAccent,
                            selectedTextColor = AmberAccent,
                            unselectedIconColor = TextMuted,
                            unselectedTextColor = TextMuted,
                            indicatorColor = Color(0xFF1E2838)
                        ),
                        modifier = Modifier.testTag("nav_settings")
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            AnimatedContent(
                targetState = currentSubScreen,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "screen_transition"
            ) { subScreen ->
                when (subScreen) {
                    SubScreen.NONE -> {
                        when (currentTab) {
                            NavigationTab.HOME -> HomeScreen(viewModel = viewModel)
                            NavigationTab.LIBRARY -> ClipLibraryScreen(viewModel = viewModel)
                            NavigationTab.CREATE -> ProjectEditorScreen(
                                viewModel = viewModel,
                                onBack = { viewModel.setTab(NavigationTab.HOME) }
                            )
                            NavigationTab.SETTINGS -> SettingsScreen(viewModel = viewModel)
                        }
                    }
                    SubScreen.CLIP_LIBRARY -> ClipLibraryScreen(
                        viewModel = viewModel,
                        showBackButton = true,
                        onBack = { viewModel.navigateBack() }
                    )
                    SubScreen.PROJECT_EDITOR -> ProjectEditorScreen(
                        viewModel = viewModel,
                        onBack = { viewModel.navigateBack() }
                    )
                    SubScreen.EDGE_TTS -> EdgeTtsScreen(
                        viewModel = viewModel,
                        onBack = { viewModel.navigateBack() }
                    )
                    SubScreen.PREVIEW -> PreviewScreen(
                        viewModel = viewModel,
                        onBack = { viewModel.navigateBack() }
                    )
                    SubScreen.EXPORTING -> ExportScreen(
                        viewModel = viewModel
                    )
                    SubScreen.COMPLETED -> CompletedScreen(
                        viewModel = viewModel,
                        onDone = {
                            viewModel.setTab(NavigationTab.HOME)
                        }
                    )
                    SubScreen.PROJECTS_LIST -> ProjectsListScreen(
                        viewModel = viewModel,
                        onBack = { viewModel.navigateBack() }
                    )
                }
            }
        }
    }
}
