package com.example.model

data class ClipItem(
    val id: String,
    val title: String,
    val durationMs: Long,
    val width: Int = 1920,
    val height: Int = 1080,
    val fps: Float = 30f,
    val filePath: String,
    val uriString: String = "",
    val isSample: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
) {
    val durationFormatted: String
        get() {
            val totalSeconds = durationMs / 1000
            val minutes = totalSeconds / 60
            val seconds = totalSeconds % 60
            return String.format("%02d:%02d", minutes, seconds)
        }
}
