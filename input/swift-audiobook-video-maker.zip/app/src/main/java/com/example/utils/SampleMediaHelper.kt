package com.example.utils

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaMuxer
import android.net.Uri
import android.util.Log
import com.example.model.ClipItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.util.UUID

object SampleMediaHelper {

    suspend fun getMediaDuration(context: Context, uri: Uri): Long = withContext(Dispatchers.IO) {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)
            val durationStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            durationStr?.toLongOrNull() ?: 60000L
        } catch (e: Exception) {
            60000L
        } finally {
            try { retriever.release() } catch (_: Exception) {}
        }
    }

    suspend fun getVideoDimensions(context: Context, uri: Uri): Pair<Int, Int> = withContext(Dispatchers.IO) {
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)
            val width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 1920
            val height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 1080
            Pair(width, height)
        } catch (e: Exception) {
            Pair(1920, 1080)
        } finally {
            try { retriever.release() } catch (_: Exception) {}
        }
    }

    suspend fun extractThumbnail(context: Context, filePath: String): Bitmap? = withContext(Dispatchers.IO) {
        val retriever = MediaMetadataRetriever()
        try {
            val file = File(filePath)
            if (file.exists()) {
                retriever.setDataSource(filePath)
            } else {
                retriever.setDataSource(context, Uri.parse(filePath))
            }
            retriever.getFrameAtTime(1000000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
        } catch (e: Exception) {
            null
        } finally {
            try { retriever.release() } catch (_: Exception) {}
        }
    }

    suspend fun copyUriToInternalStorage(context: Context, uri: Uri, fileNamePrefix: String, extension: String): File = withContext(Dispatchers.IO) {
        val outputDir = File(context.filesDir, "media_library").apply { mkdirs() }
        val destFile = File(outputDir, "${fileNamePrefix}_${System.currentTimeMillis()}.$extension")
        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(destFile).use { output ->
                input.copyTo(output)
            }
        }
        destFile
    }

    /**
     * Pre-generates polished ambient background loop MP4 video files
     * so that users have ready-to-use background clips immediately.
     */
    suspend fun generatePresetClips(context: Context): List<ClipItem> = withContext(Dispatchers.IO) {
        val outputDir = File(context.filesDir, "preset_loops").apply { mkdirs() }
        val presets = listOf(
            Triple("Cosmic Starlight Ambient Loop", "cosmic_starlight.mp4", 0xFF0B0E1B to 0xFF1E1B4B),
            Triple("Cozy Hearth Fireside Loop", "cozy_fireside.mp4", 0xFF1C0E06 to 0xFF451A03),
            Triple("Zen Sunset Horizon Loop", "zen_sunset.mp4", 0xFF1E102F to 0xFF831843),
            Triple("Deep Ocean Serenity Loop", "deep_ocean.mp4", 0xFF041E2B to 0xFF0E3A53)
        )

        val resultClips = mutableListOf<ClipItem>()

        for ((title, filename, colors) in presets) {
            val file = File(outputDir, filename)
            if (!file.exists() || file.length() < 1000) {
                createSyntheticAmbientVideo(file, title, colors.first.toInt(), colors.second.toInt(), durationSeconds = 10)
            }
            resultClips.add(
                ClipItem(
                    id = "preset_${filename.substringBefore('.')}",
                    title = title,
                    durationMs = 10000L,
                    width = 1280,
                    height = 720,
                    fps = 30f,
                    filePath = file.absolutePath,
                    uriString = Uri.fromFile(file).toString(),
                    isSample = true
                )
            )
        }
        resultClips
    }

    /**
     * Encodes a lightweight, beautiful animated ambient background video loop with H.264
     */
    private fun createSyntheticAmbientVideo(
        outputFile: File,
        title: String,
        colorStart: Int,
        colorEnd: Int,
        durationSeconds: Int = 6
    ) {
        val width = 640
        val height = 360
        val fps = 30
        val bitRate = 1000000
        val totalFrames = durationSeconds * fps

        var muxer: MediaMuxer? = null
        var encoder: MediaCodec? = null
        var muxerStarted = false
        var videoTrackIndex = -1
        var videoSamplesWritten = 0

        try {
            val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, bitRate)
                setInteger(MediaFormat.KEY_FRAME_RATE, fps)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
            }

            encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            val inputSurface = encoder.createInputSurface()
            encoder.start()

            val bufferInfo = MediaCodec.BufferInfo()
            val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = 28f
                textAlign = Paint.Align.CENTER
                isFakeBoldText = true
                setShadowLayer(6f, 0f, 3f, Color.BLACK)
            }
            val subtitlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = 0xFFFFA14A.toInt()
                textSize = 16f
                textAlign = Paint.Align.CENTER
                letterSpacing = 0.12f
            }
            val particlePaint = Paint(Paint.ANTI_ALIAS_FLAG)

            for (frameIndex in 0 until totalFrames) {
                // Render frame onto surface
                val canvas: Canvas = inputSurface.lockCanvas(null)
                val progress = frameIndex.toFloat() / totalFrames
                val angle = progress * Math.PI * 2

                // Background gradient
                val gradient = LinearGradient(
                    0f, 0f,
                    width.toFloat() * (0.5f + 0.3f * Math.cos(angle).toFloat()),
                    height.toFloat() * (0.5f + 0.3f * Math.sin(angle).toFloat()),
                    colorStart,
                    colorEnd,
                    Shader.TileMode.CLAMP
                )
                val bgPaint = Paint().apply { shader = gradient }
                canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

                // Soft radial glow
                val glowX = width * (0.5f + 0.2f * Math.sin(angle).toFloat())
                val glowY = height * (0.5f + 0.15f * Math.cos(angle).toFloat())
                val radialGlow = RadialGradient(
                    glowX, glowY,
                    height * 0.6f,
                    intArrayOf(0x55FFA14A.toInt(), 0x00000000),
                    floatArrayOf(0f, 1f),
                    Shader.TileMode.CLAMP
                )
                val glowPaint = Paint().apply { shader = radialGlow }
                canvas.drawCircle(glowX, glowY, height * 0.6f, glowPaint)

                // Ambient particles
                for (p in 0..16) {
                    val px = (Math.sin(p * 45.0 + angle) * 0.4 + 0.5) * width
                    val py = (Math.cos(p * 33.0 + angle * 0.8) * 0.4 + 0.5) * height
                    val radius = (Math.sin(p + angle * 2) * 2 + 4).toFloat()
                    val alpha = ((Math.sin(p * 2 + angle) * 0.3 + 0.5) * 255).toInt().coerceIn(40, 200)
                    particlePaint.color = 0x00FFFFFF or (alpha shl 24)
                    canvas.drawCircle(px.toFloat(), py.toFloat(), radius, particlePaint)
                }

                // Title overlay
                canvas.drawText(title, width / 2f, height / 2f - 8f, textPaint)
                canvas.drawText("AUDIOBOOK CINEMATIC BACKGROUND", width / 2f, height / 2f + 32f, subtitlePaint)

                inputSurface.unlockCanvasAndPost(canvas)

                // Drain encoder
                while (true) {
                    val status = encoder.dequeueOutputBuffer(bufferInfo, 2000)
                    if (status == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        if (muxer == null) {
                            muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
                            videoTrackIndex = muxer.addTrack(encoder.outputFormat)
                            muxer.start()
                            muxerStarted = true
                        }
                    } else if (status >= 0) {
                        val encodedBuffer = encoder.getOutputBuffer(status)
                        if (encodedBuffer != null && muxerStarted && (bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                            muxer?.writeSampleData(videoTrackIndex, encodedBuffer, bufferInfo)
                            videoSamplesWritten++
                        }
                        encoder.releaseOutputBuffer(status, false)
                    } else {
                        break
                    }
                }
            }

            try {
                encoder.signalEndOfInputStream()
            } catch (_: Exception) {}

            var eosReached = false
            var drainAttempts = 0
            while (!eosReached && drainAttempts < 30) {
                val status = encoder.dequeueOutputBuffer(bufferInfo, 10000)
                if (status == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    if (muxer == null) {
                        muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
                        videoTrackIndex = muxer.addTrack(encoder.outputFormat)
                        muxer.start()
                        muxerStarted = true
                    }
                } else if (status >= 0) {
                    val encodedBuffer = encoder.getOutputBuffer(status)
                    if (encodedBuffer != null && muxerStarted && (bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                        muxer?.writeSampleData(videoTrackIndex, encodedBuffer, bufferInfo)
                        videoSamplesWritten++
                    }
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        eosReached = true
                    }
                    encoder.releaseOutputBuffer(status, false)
                } else if (status == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    drainAttempts++
                } else {
                    break
                }
            }

            if (muxerStarted && videoSamplesWritten > 0) {
                try {
                    muxer?.stop()
                } catch (e: Exception) {
                    Log.e("SampleMediaHelper", "Muxer stop failed", e)
                }
            }
        } catch (e: Exception) {
            Log.e("SampleMediaHelper", "Failed creating synthetic ambient video", e)
        } finally {
            try { encoder?.stop() } catch (_: Exception) {}
            try { encoder?.release() } catch (_: Exception) {}
            if (muxerStarted) {
                try { muxer?.release() } catch (_: Exception) {}
            }
        }
    }

    /**
     * Generates a sample audiobook narration audio file for instant demo with spoken voice
     */
    suspend fun generateSampleAudiobookFile(context: Context, title: String, durationSec: Int = 45): File = withContext(Dispatchers.IO) {
        val outputDir = File(context.filesDir, "audio_library").apply { mkdirs() }
        val audioFile = File(outputDir, "sample_audiobook_${UUID.randomUUID().toString().take(6)}.wav")
        val sampleText = "Welcome to $title. In this chapter, the journey begins across scenic horizons. As the narrator speaks, the video clips dynamically sync in harmony with the spoken words."
        val success = com.example.tts.AndroidSpeechTtsEngine.synthesizeTextToFile(
            context = context,
            text = sampleText,
            outputFile = audioFile
        )

        if (success && audioFile.exists() && audioFile.length() > 100) {
            val aacFile = com.example.engine.AudioTranscoder.convertToM4aAac(context, audioFile)
            if (aacFile.exists() && aacFile.length() > 500) {
                try { audioFile.delete() } catch (_: Exception) {}
                return@withContext aacFile
            }
            return@withContext audioFile
        }

        // Fallback gentle musical arpeggio (soft bell tones instead of harsh buzzer)
        val mp4Fallback = File(outputDir, "sample_audio_${UUID.randomUUID().toString().take(6)}.mp4")
        val sampleRate = 44100
        val bitRate = 128000
        val totalSamples = sampleRate * durationSec

        var muxer: MediaMuxer? = null
        var encoder: MediaCodec? = null

        try {
            val format = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, sampleRate, 2).apply {
                setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_BIT_RATE, bitRate)
            }

            encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            encoder.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            encoder.start()

            muxer = MediaMuxer(mp4Fallback.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            var audioTrackIndex = -1
            var muxerStarted = false

            val bufferInfo = MediaCodec.BufferInfo()
            var samplesSubmitted = 0
            val pcmChunk = ShortArray(2048)
            var audioSamplesWritten = 0

            // Pentatonic warm chime frequencies: C4, E4, G4, A4, C5
            val pentatonicNotes = doubleArrayOf(261.63, 329.63, 392.00, 440.00, 523.25)

            while (samplesSubmitted < totalSamples) {
                val inputIndex = encoder.dequeueInputBuffer(10000)
                if (inputIndex >= 0) {
                    val inputBuffer = encoder.getInputBuffer(inputIndex)
                    if (inputBuffer != null) {
                        inputBuffer.clear()
                        for (i in pcmChunk.indices step 2) {
                            val t = (samplesSubmitted + i / 2).toDouble() / sampleRate
                            val noteIdx = ((t * 2.0).toInt()) % pentatonicNotes.size
                            val freq = pentatonicNotes[noteIdx]
                            val beatPhase = (t * 2.0) % 1.0
                            val decay = Math.exp(-3.0 * beatPhase)
                            val sampleValue = (Math.sin(2.0 * Math.PI * freq * t) * 4000.0 * decay).toInt().toShort()
                            pcmChunk[i] = sampleValue
                            pcmChunk[i + 1] = sampleValue
                        }
                        val byteBuf = ByteBuffer.allocate(pcmChunk.size * 2)
                        for (s in pcmChunk) byteBuf.putShort(s)
                        byteBuf.flip()
                        inputBuffer.put(byteBuf)

                        val ptsUs = (samplesSubmitted * 1_000_000L) / sampleRate
                        encoder.queueInputBuffer(inputIndex, 0, pcmChunk.size * 2, ptsUs, 0)
                        samplesSubmitted += pcmChunk.size / 2
                    }
                }

                while (true) {
                    val status = encoder.dequeueOutputBuffer(bufferInfo, 10000)
                    if (status == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        audioTrackIndex = muxer.addTrack(encoder.outputFormat)
                        muxer.start()
                        muxerStarted = true
                    } else if (status >= 0) {
                        val outBuf = encoder.getOutputBuffer(status)
                        if (outBuf != null && muxerStarted && (bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                            muxer.writeSampleData(audioTrackIndex, outBuf, bufferInfo)
                            audioSamplesWritten++
                        }
                        encoder.releaseOutputBuffer(status, false)
                        break
                    } else {
                        break
                    }
                }
            }

            // Signal EOS
            val eosIndex = encoder.dequeueInputBuffer(10000)
            if (eosIndex >= 0) {
                encoder.queueInputBuffer(eosIndex, 0, 0, (totalSamples * 1_000_000L) / sampleRate, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
            }

            while (true) {
                val status = encoder.dequeueOutputBuffer(bufferInfo, 10000)
                if (status >= 0) {
                    val outBuf = encoder.getOutputBuffer(status)
                    if (outBuf != null && muxerStarted && (bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                        muxer.writeSampleData(audioTrackIndex, outBuf, bufferInfo)
                        audioSamplesWritten++
                    }
                    encoder.releaseOutputBuffer(status, false)
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break
                } else if (status == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    break
                }
            }

            if (muxerStarted && audioSamplesWritten > 0) {
                try {
                    muxer.stop()
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            try { encoder?.stop() } catch (_: Exception) {}
            try { encoder?.release() } catch (_: Exception) {}
            try { muxer?.release() } catch (_: Exception) {}
        }

        mp4Fallback
    }
}
