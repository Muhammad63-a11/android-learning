package com.example.model

data class ProjectItem(
    val id: String,
    val title: String,
    val clipIds: List<String> = emptyList(),
    val audioItem: AudioItem? = null,
    val loopStrategy: String = "CENTER_CLIP_LOOP",
    val customRepeatClipId: String? = null,
    val audioStartOffsetSec: Float = 0f,
    val audioEndOffsetSec: Float = 0f,
    val audioVolume: Float = 1.0f,
    val videoVolume: Float = 0.0f,
    val exportPipEnabled: Boolean = false,
    val pipClipId: String? = null,
    val pipPosition: String = "TOP_RIGHT",
    val pipScale: Float = 0.25f,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val lastExportedPath: String? = null,
    val lastExportDurationMs: Long = 0L,
    val lastExportFileSize: Long = 0L,
    val lastExportSpeedFactor: Float = 0f
)
