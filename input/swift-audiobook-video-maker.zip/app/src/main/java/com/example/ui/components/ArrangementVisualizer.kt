package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Loop
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ArrangedTimeline
import com.example.model.LoopStrategy
import com.example.model.SegmentRole
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.AmberContainer
import com.example.ui.theme.GreenSuccess
import com.example.ui.theme.SkyAccent
import com.example.ui.theme.SlateBorder
import com.example.ui.theme.SlateCardSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun ArrangementVisualizer(
    timeline: ArrangedTimeline?,
    modifier: Modifier = Modifier,
    activeSegmentIndex: Int? = null,
    onSegmentClick: ((index: Int) -> Unit)? = null
) {
    if (timeline == null || timeline.segments.isEmpty()) {
        Surface(
            modifier = modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            color = SlateCardSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Default.Loop,
                    contentDescription = null,
                    tint = TextMuted,
                    modifier = Modifier.size(32.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "Select clips & audio to compute auto-loop timeline",
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
            }
        }
        return
    }

    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        color = SlateCardSurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = AmberAccent,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Auto-Arranged Timeline",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(AmberContainer)
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "Video: ${timeline.totalVideoDurationFormatted}",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = AmberAccent
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Stat pills
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val strategyLabel = when (timeline.loopStrategy) {
                    LoopStrategy.CENTER_CLIP_LOOP -> "Center Loop"
                    LoopStrategy.REPEAT_ALL_CLIPS -> "Repeat All"
                    LoopStrategy.REPEAT_CUSTOM_CLIP -> "Custom Loop"
                }

                StatPill(
                    icon = Icons.Default.Repeat,
                    label = "Strategy",
                    value = strategyLabel,
                    color = SkyAccent,
                    modifier = Modifier.weight(1f)
                )
                StatPill(
                    icon = Icons.Default.MusicNote,
                    label = "Audio Span",
                    value = timeline.audioSpanFormatted,
                    color = AmberAccent,
                    modifier = Modifier.weight(1.3f)
                )
                StatPill(
                    icon = Icons.Default.Timer,
                    label = "Segments",
                    value = "${timeline.totalSegmentsCount} clips",
                    color = GreenSuccess,
                    modifier = Modifier.weight(0.9f)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Sequence timeline track
            Text(
                text = "TIMELINE SEQUENCE (${timeline.segments.size} SEGMENTS)",
                style = MaterialTheme.typography.labelSmall,
                letterSpacing = 0.8.sp,
                fontWeight = FontWeight.Bold,
                color = TextMuted
            )

            Spacer(modifier = Modifier.height(8.dp))

            val scrollState = rememberScrollState()
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(scrollState),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                timeline.segments.forEach { seg ->
                    val isCurrent = activeSegmentIndex == seg.index
                    val isTrimmed = seg.role == SegmentRole.SECOND_LAST_TRIMMED || seg.isFinalTrimmedSegment
                    val isIntro = seg.role == SegmentRole.INTRO_FIRST
                    val isOutro = seg.role == SegmentRole.OUTRO_LAST

                    val bgGradient = when {
                        isCurrent -> Brush.horizontalGradient(listOf(Color(0xFF3F2B0C), Color(0xFF6B450E)))
                        isTrimmed -> Brush.horizontalGradient(listOf(Color(0xFF381F0E), Color(0xFF56260C)))
                        isIntro -> Brush.horizontalGradient(listOf(Color(0xFF0F263B), Color(0xFF193B5C)))
                        isOutro -> Brush.horizontalGradient(listOf(Color(0xFF132B25), Color(0xFF1C483D)))
                        else -> Brush.horizontalGradient(listOf(Color(0xFF131D2A), Color(0xFF1C2B3E)))
                    }

                    val borderColor = when {
                        isCurrent -> AmberAccent
                        isTrimmed -> Color(0xFFF59E0B)
                        isIntro -> SkyAccent.copy(alpha = 0.8f)
                        isOutro -> GreenSuccess.copy(alpha = 0.8f)
                        else -> SlateBorder
                    }

                    Box(
                        modifier = Modifier
                            .width(140.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(bgGradient)
                            .border(if (isCurrent) 2.dp else 1.dp, borderColor, RoundedCornerShape(10.dp))
                            .clickable(enabled = onSegmentClick != null) {
                                onSegmentClick?.invoke(seg.index)
                            }
                            .padding(9.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "#${seg.index + 1}",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isTrimmed || isCurrent) AmberAccent else SkyAccent
                                )

                                val tagText = when (seg.role) {
                                    SegmentRole.INTRO_FIRST -> "INTRO"
                                    SegmentRole.OUTRO_LAST -> "OUTRO"
                                    SegmentRole.SECOND_LAST_TRIMMED -> "TRIMMED"
                                    SegmentRole.CENTER_LOOP -> "LOOP"
                                    SegmentRole.SINGLE_REPEATING -> if (isTrimmed) "TRIMMED" else "LOOP"
                                    SegmentRole.CUSTOM_LOOP_SEGMENT -> if (isTrimmed) "TRIMMED" else "CUSTOM LOOP"
                                }

                                val tagColor = when (seg.role) {
                                    SegmentRole.INTRO_FIRST -> SkyAccent
                                    SegmentRole.OUTRO_LAST -> GreenSuccess
                                    SegmentRole.SECOND_LAST_TRIMMED -> AmberAccent
                                    SegmentRole.CENTER_LOOP -> TextMuted
                                    SegmentRole.SINGLE_REPEATING -> if (isTrimmed) AmberAccent else TextMuted
                                    SegmentRole.CUSTOM_LOOP_SEGMENT -> AmberAccent
                                }

                                Text(
                                    text = tagText,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = tagColor
                                )
                            }

                            Spacer(modifier = Modifier.height(3.dp))

                            Text(
                                text = seg.clipTitle,
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.SemiBold,
                                color = TextPrimary,
                                maxLines = 1
                            )

                            Spacer(modifier = Modifier.height(4.dp))

                            Text(
                                text = seg.durationFormatted,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (isTrimmed) AmberAccent else TextSecondary
                            )

                            Text(
                                text = seg.timeRangeFormatted,
                                style = MaterialTheme.typography.labelSmall,
                                fontSize = 9.sp,
                                color = TextMuted
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Logic explainer banner
            val ruleDescription = when (timeline.loopStrategy) {
                LoopStrategy.CENTER_CLIP_LOOP -> "Rules Applied: 1st clip is Intro (1x), center clips loop, 2nd-to-last clip is trimmed to fit exact remainder, and last clip is Outro (1x)."
                LoopStrategy.REPEAT_ALL_CLIPS -> "Rules Applied: All selected clips cycle in sequence to reach the total video duration, with the final clip trimmed to the exact second."
                LoopStrategy.REPEAT_CUSTOM_CLIP -> "Rules Applied: Preserves start & end clips while repeating your chosen custom clip to fill the exact required duration."
            }

            val offsetDescription = if (timeline.audioStartOffsetMs > 0 || timeline.audioEndOffsetMs > 0) {
                val startSec = timeline.audioStartOffsetMs / 1000f
                val endSec = timeline.audioEndOffsetMs / 1000f
                "\n• Audio Timing: Starts ${startSec}s into video, and video ends ${endSec}s after audio completes."
            } else ""

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF0F1722))
                    .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "$ruleDescription$offsetDescription",
                    style = MaterialTheme.typography.bodySmall,
                    fontSize = 11.sp,
                    color = TextSecondary,
                    lineHeight = 15.sp
                )
            }
        }
    }
}

@Composable
private fun StatPill(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0xFF0E141D))
            .border(1.dp, Color(0xFF222C3A), RoundedCornerShape(10.dp))
            .padding(8.dp)
    ) {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = color,
                    modifier = Modifier.size(12.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = label,
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 10.sp,
                    color = TextMuted
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.bodySmall,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                maxLines = 1
            )
        }
    }
}
