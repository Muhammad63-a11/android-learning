package com.example.tts

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.util.Locale
import java.util.UUID

object AndroidSpeechTtsEngine {

    suspend fun synthesizeTextToFile(
        context: Context,
        text: String,
        outputFile: File,
        locale: Locale = Locale.US,
        speed: Float = 1.0f,
        pitch: Float = 1.0f
    ): Boolean = withContext(Dispatchers.Main) {
        val initDeferred = CompletableDeferred<Boolean>()
        val utteranceDeferred = CompletableDeferred<Boolean>()
        var ttsInstance: TextToSpeech? = null

        try {
            ttsInstance = TextToSpeech(context.applicationContext) { status ->
                if (status == TextToSpeech.SUCCESS) {
                    initDeferred.complete(true)
                } else {
                    initDeferred.complete(false)
                }
            }

            val initialized = withTimeoutOrNull(5000L) {
                initDeferred.await()
            } ?: false

            if (!initialized || ttsInstance == null) {
                return@withContext false
            }

            val tts = ttsInstance
            tts.language = locale
            tts.setSpeechRate(speed.coerceIn(0.5f, 2.0f))
            tts.setPitch(pitch.coerceIn(0.5f, 2.0f))

            val utteranceId = "tts_${UUID.randomUUID()}"
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}

                override fun onDone(utteranceId: String?) {
                    utteranceDeferred.complete(true)
                }

                override fun onError(utteranceId: String?) {
                    utteranceDeferred.complete(false)
                }

                override fun onError(utteranceId: String?, errorCode: Int) {
                    utteranceDeferred.complete(false)
                }
            })

            val params = Bundle()
            val result = tts.synthesizeToFile(text, params, outputFile, utteranceId)
            if (result != TextToSpeech.SUCCESS) {
                return@withContext false
            }

            val finished = withTimeoutOrNull(20000L) {
                utteranceDeferred.await()
            } ?: false

            finished && outputFile.exists() && outputFile.length() > 200
        } catch (e: Exception) {
            e.printStackTrace()
            false
        } finally {
            try {
                ttsInstance?.stop()
                ttsInstance?.shutdown()
            } catch (_: Exception) {}
        }
    }
}
