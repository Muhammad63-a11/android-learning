package com.example.engine

import android.content.Context
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

object AudioTranscoder {

    private const val TAG = "AudioTranscoder"

    /**
     * Converts any audio file (WAV PCM, MP3, OGG, AAC, etc.) into an MPEG-4 AAC (.m4a) file
     * with volume scaling and 100% compatibility with Android MediaMuxer.
     */
    suspend fun convertToM4aAac(
        context: Context,
        inputFile: File,
        volume: Float = 1.0f
    ): File = withContext(Dispatchers.IO) {
        if (!inputFile.exists() || inputFile.length() == 0L) {
            return@withContext inputFile
        }

        val outputDir = File(context.cacheDir, "transcoded_audio").apply { mkdirs() }
        val outputFile = File(outputDir, "audio_${System.currentTimeMillis()}_${inputFile.nameWithoutExtension}.m4a")

        // 1. If it's already an AAC M4A and volume is standard (1.0f), no transcoding needed
        if (isAlreadyAacM4a(inputFile) && kotlin.math.abs(volume - 1.0f) < 0.02f) {
            return@withContext inputFile
        }

        // 2. If it is a WAV file, perform fast direct PCM-to-AAC encoding with volume gain
        if (isWavFile(inputFile)) {
            val wavSuccess = encodeWavToAac(inputFile, outputFile, volume)
            if (wavSuccess && outputFile.exists() && outputFile.length() > 500) {
                return@withContext outputFile
            }
        }

        // 3. General decode -> volume gain -> encode pipeline via MediaCodec for MP3/OGG/AAC/etc.
        val transcodeSuccess = transcodeAnyAudioToAac(inputFile, outputFile, volume)
        if (transcodeSuccess && outputFile.exists() && outputFile.length() > 500) {
            return@withContext outputFile
        }

        // Fallback: return original file
        inputFile
    }

    private fun isAlreadyAacM4a(file: File): Boolean {
        val extractor = MediaExtractor()
        try {
            extractor.setDataSource(file.absolutePath)
            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime == MediaFormat.MIMETYPE_AUDIO_AAC || mime == "audio/mp4a-latm") {
                    return true
                }
            }
        } catch (_: Exception) {
        } finally {
            try { extractor.release() } catch (_: Exception) {}
        }
        return false
    }

    private fun isWavFile(file: File): Boolean {
        if (!file.exists() || file.length() < 44) return false
        try {
            FileInputStream(file).use { fis ->
                val header = ByteArray(12)
                val read = fis.read(header)
                if (read >= 12) {
                    val riff = String(header, 0, 4)
                    val wave = String(header, 8, 4)
                    return riff == "RIFF" && wave == "WAVE"
                }
            }
        } catch (_: Exception) {}
        return false
    }

    /**
     * Reads PCM audio bytes from a standard WAV file and encodes them directly to AAC with volume gain
     */
    private fun encodeWavToAac(wavFile: File, outputFile: File, volume: Float): Boolean {
        var fis: FileInputStream? = null
        var encoder: MediaCodec? = null
        var muxer: MediaMuxer? = null
        var muxerStarted = false
        var audioTrackIndex = -1
        var samplesWritten = 0

        try {
            fis = FileInputStream(wavFile)
            val header = ByteArray(44)
            if (fis.read(header) < 44) return false

            val channels = ByteBuffer.wrap(header, 22, 2).order(ByteOrder.LITTLE_ENDIAN).short.toInt().coerceIn(1, 2)
            val sampleRate = ByteBuffer.wrap(header, 24, 4).order(ByteOrder.LITTLE_ENDIAN).int.coerceIn(8000, 48000)
            val bitsPerSample = ByteBuffer.wrap(header, 34, 2).order(ByteOrder.LITTLE_ENDIAN).short.toInt()

            if (bitsPerSample != 16 && bitsPerSample != 8) {
                return false
            }

            val aacFormat = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, sampleRate, channels).apply {
                setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_BIT_RATE, 128000)
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
            }

            encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            encoder.configure(aacFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            encoder.start()

            val bufferInfo = MediaCodec.BufferInfo()
            val chunk = ByteArray(4096)
            var totalBytesRead = 0L
            var isEos = false
            val bytesPerSample = (channels * bitsPerSample) / 8

            while (!isEos) {
                val inputIndex = encoder.dequeueInputBuffer(10000)
                if (inputIndex >= 0) {
                    val inputBuf = encoder.getInputBuffer(inputIndex)
                    if (inputBuf != null) {
                        inputBuf.clear()
                        val bytesRead = fis.read(chunk)
                        if (bytesRead > 0) {
                            if (kotlin.math.abs(volume - 1.0f) > 0.02f && bitsPerSample == 16) {
                                applyVolumeGain(chunk, bytesRead, volume)
                            }
                            inputBuf.put(chunk, 0, bytesRead)
                            val ptsUs = (totalBytesRead * 1_000_000L) / (sampleRate * bytesPerSample)
                            encoder.queueInputBuffer(inputIndex, 0, bytesRead, ptsUs, 0)
                            totalBytesRead += bytesRead
                        } else {
                            val ptsUs = (totalBytesRead * 1_000_000L) / (sampleRate * bytesPerSample)
                            encoder.queueInputBuffer(inputIndex, 0, 0, ptsUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            isEos = true
                        }
                    }
                }

                while (true) {
                    val status = encoder.dequeueOutputBuffer(bufferInfo, 5000)
                    if (status == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        if (muxer == null) {
                            muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
                            audioTrackIndex = muxer.addTrack(encoder.outputFormat)
                            muxer.start()
                            muxerStarted = true
                        }
                    } else if (status >= 0) {
                        val outBuf = encoder.getOutputBuffer(status)
                        if (outBuf != null && muxerStarted && (bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                            muxer?.writeSampleData(audioTrackIndex, outBuf, bufferInfo)
                            samplesWritten++
                        }
                        encoder.releaseOutputBuffer(status, false)
                        if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                            isEos = true
                        }
                        break
                    } else {
                        break
                    }
                }
            }

            var drainAttempts = 0
            while (drainAttempts < 20) {
                val status = encoder.dequeueOutputBuffer(bufferInfo, 10000)
                if (status >= 0) {
                    val outBuf = encoder.getOutputBuffer(status)
                    if (outBuf != null && muxerStarted && (bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                        muxer?.writeSampleData(audioTrackIndex, outBuf, bufferInfo)
                        samplesWritten++
                    }
                    encoder.releaseOutputBuffer(status, false)
                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break
                } else {
                    drainAttempts++
                }
            }

            if (muxerStarted && samplesWritten > 0) {
                try { muxer?.stop() } catch (e: Exception) { Log.e(TAG, "Muxer stop error", e) }
            }

            return muxerStarted && samplesWritten > 0
        } catch (e: Exception) {
            Log.e(TAG, "WAV to AAC failed", e)
            return false
        } finally {
            try { fis?.close() } catch (_: Exception) {}
            try { encoder?.stop() } catch (_: Exception) {}
            try { encoder?.release() } catch (_: Exception) {}
            if (muxerStarted) {
                try { muxer?.release() } catch (_: Exception) {}
            }
        }
    }

    /**
     * Decodes any audio via MediaCodec, applies volume gain, and re-encodes to AAC
     */
    private fun transcodeAnyAudioToAac(inputFile: File, outputFile: File, volume: Float): Boolean {
        val extractor = MediaExtractor()
        var decoder: MediaCodec? = null
        var encoder: MediaCodec? = null
        var muxer: MediaMuxer? = null
        var muxerTrackIndex = -1
        var muxerStarted = false
        var samplesWritten = 0

        try {
            extractor.setDataSource(inputFile.absolutePath)
            var audioTrackIdx = -1
            var inputFormat: MediaFormat? = null

            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("audio/")) {
                    audioTrackIdx = i
                    inputFormat = format
                    break
                }
            }

            if (audioTrackIdx == -1 || inputFormat == null) {
                return false
            }

            extractor.selectTrack(audioTrackIdx)

            val mime = inputFormat.getString(MediaFormat.KEY_MIME) ?: ""
            val sampleRate = if (inputFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)) inputFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 44100
            val channelCount = if (inputFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) inputFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 2

            decoder = MediaCodec.createDecoderByType(mime)
            decoder.configure(inputFormat, null, null, 0)
            decoder.start()

            val aacFormat = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, sampleRate, channelCount).apply {
                setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_BIT_RATE, 128000)
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
            }

            encoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            encoder.configure(aacFormat, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            encoder.start()

            val decBufferInfo = MediaCodec.BufferInfo()
            val encBufferInfo = MediaCodec.BufferInfo()
            var extractorEos = false
            var decoderEos = false
            var encoderEos = false

            var noWorkCount = 0
            while (!encoderEos) {
                var didWork = false

                // 1. Feed Extractor to Decoder
                if (!extractorEos) {
                    val inIdx = decoder.dequeueInputBuffer(2500)
                    if (inIdx >= 0) {
                        val inBuf = decoder.getInputBuffer(inIdx)
                        if (inBuf != null) {
                            val sampleSize = extractor.readSampleData(inBuf, 0)
                            if (sampleSize < 0) {
                                decoder.queueInputBuffer(inIdx, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                extractorEos = true
                            } else {
                                decoder.queueInputBuffer(inIdx, 0, sampleSize, extractor.sampleTime, 0)
                                extractor.advance()
                            }
                            didWork = true
                        }
                    }
                }

                // 2. Read PCM from Decoder, apply volume, feed to Encoder
                while (!decoderEos) {
                    val decOutIdx = decoder.dequeueOutputBuffer(decBufferInfo, 2500)
                    if (decOutIdx >= 0) {
                        didWork = true
                        val pcmBuf = decoder.getOutputBuffer(decOutIdx)
                        val isDecEos = (decBufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0

                        if (pcmBuf != null && decBufferInfo.size > 0) {
                            val encInIdx = encoder.dequeueInputBuffer(2500)
                            if (encInIdx >= 0) {
                                val encInBuf = encoder.getInputBuffer(encInIdx)
                                if (encInBuf != null) {
                                    encInBuf.clear()
                                    pcmBuf.position(decBufferInfo.offset)
                                    pcmBuf.limit(decBufferInfo.offset + decBufferInfo.size)

                                    if (kotlin.math.abs(volume - 1.0f) > 0.02f) {
                                        applyVolumeGainToByteBuffer(pcmBuf, encInBuf, volume)
                                    } else {
                                        encInBuf.put(pcmBuf)
                                    }

                                    encoder.queueInputBuffer(
                                        encInIdx,
                                        0,
                                        decBufferInfo.size,
                                        decBufferInfo.presentationTimeUs,
                                        if (isDecEos) MediaCodec.BUFFER_FLAG_END_OF_STREAM else 0
                                    )
                                }
                            }
                        } else if (isDecEos) {
                            val encInIdx = encoder.dequeueInputBuffer(2500)
                            if (encInIdx >= 0) {
                                encoder.queueInputBuffer(encInIdx, 0, 0, decBufferInfo.presentationTimeUs, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            }
                        }

                        if (isDecEos) decoderEos = true
                        decoder.releaseOutputBuffer(decOutIdx, false)
                    } else {
                        break
                    }
                }

                // 3. Read AAC from Encoder and write to Muxer
                while (true) {
                    val encOutIdx = encoder.dequeueOutputBuffer(encBufferInfo, 2500)
                    if (encOutIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        didWork = true
                        if (muxer == null) {
                            muxer = MediaMuxer(outputFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
                            muxerTrackIndex = muxer.addTrack(encoder.outputFormat)
                            muxer.start()
                            muxerStarted = true
                        }
                    } else if (encOutIdx >= 0) {
                        didWork = true
                        val encOutBuf = encoder.getOutputBuffer(encOutIdx)
                        if (encOutBuf != null && muxerStarted && (encBufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0) {
                            muxer?.writeSampleData(muxerTrackIndex, encOutBuf, encBufferInfo)
                            samplesWritten++
                        }
                        encoder.releaseOutputBuffer(encOutIdx, false)
                        if ((encBufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                            encoderEos = true
                            break
                        }
                    } else {
                        break
                    }
                }

                if (!didWork) {
                    noWorkCount++
                    if (noWorkCount > 50 && extractorEos && decoderEos) {
                        // All inputs finished, drain complete
                        break
                    }
                } else {
                    noWorkCount = 0
                }
            }

            if (muxerStarted && samplesWritten > 0) {
                try { muxer?.stop() } catch (e: Exception) { Log.e(TAG, "Muxer stop error", e) }
            }

            return muxerStarted && samplesWritten > 0
        } catch (e: Exception) {
            Log.e(TAG, "Audio transcoding failed", e)
            return false
        } finally {
            try { extractor.release() } catch (_: Exception) {}
            try { decoder?.stop() } catch (_: Exception) {}
            try { decoder?.release() } catch (_: Exception) {}
            try { encoder?.stop() } catch (_: Exception) {}
            try { encoder?.release() } catch (_: Exception) {}
            if (muxerStarted) {
                try { muxer?.release() } catch (_: Exception) {}
            }
        }
    }

    private fun applyVolumeGain(bytes: ByteArray, size: Int, volume: Float) {
        val shortCount = size / 2
        for (i in 0 until shortCount) {
            val idx = i * 2
            val low = bytes[idx].toInt() and 0xFF
            val high = bytes[idx + 1].toInt()
            val sample = (high shl 8) or low
            val scaled = (sample * volume).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
            bytes[idx] = (scaled and 0xFF).toByte()
            bytes[idx + 1] = ((scaled shr 8) and 0xFF).toByte()
        }
    }

    private fun applyVolumeGainToByteBuffer(src: ByteBuffer, dst: ByteBuffer, volume: Float) {
        while (src.remaining() >= 2) {
            val sample = src.short
            val scaled = (sample * volume).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
            dst.putShort(scaled)
        }
        if (src.hasRemaining()) {
            dst.put(src.get())
        }
    }
}
