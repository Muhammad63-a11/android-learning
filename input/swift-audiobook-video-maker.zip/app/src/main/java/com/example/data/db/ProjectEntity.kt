package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.model.AudioItem
import com.example.model.ProjectItem

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey val id: String,
    val title: String,
    val clipIdsJson: String,
    val loopStrategy: String = "CENTER_CLIP_LOOP",
    val customRepeatClipId: String? = null,
    val audioStartOffsetSec: Float = 0f,
    val audioEndOffsetSec: Float = 0f,
    val audioVolume: Float = 1.0f,
    val videoVolume: Float = 0.0f,
    // Audio fields
    val audioId: String?,
    val audioTitle: String?,
    val audioDurationMs: Long?,
    val audioFilePath: String?,
    val audioUriString: String?,
    val audioVolumeField: Float,
    val audioFadeInSec: Float,
    val audioFadeOutSec: Float,
    val audioStartTrimMs: Long,
    val audioEndTrimMs: Long,
    val audioIsTtsGenerated: Boolean,
    val audioTtsText: String?,
    val audioTtsVoice: String?,
    val audioTtsLanguage: String?,
    val audioTtsSpeed: Float,
    val audioTtsPitch: Int,
    // PIP fields
    val exportPipEnabled: Boolean,
    val pipClipId: String?,
    val pipPosition: String,
    val pipScale: Float,
    // Metadata
    val createdAt: Long,
    val updatedAt: Long,
    val lastExportedPath: String?,
    val lastExportDurationMs: Long,
    val lastExportFileSize: Long,
    val lastExportSpeedFactor: Float
) {
    fun toDomain(): ProjectItem {
        val clipList = if (clipIdsJson.isBlank()) emptyList() else clipIdsJson.split(",").filter { it.isNotBlank() }
        val audio = if (audioId != null && audioFilePath != null) {
            AudioItem(
                id = audioId,
                title = audioTitle ?: "Audiobook Audio",
                durationMs = audioDurationMs ?: 0L,
                filePath = audioFilePath,
                uriString = audioUriString ?: "",
                volume = audioVolumeField,
                fadeInSec = audioFadeInSec,
                fadeOutSec = audioFadeOutSec,
                startTrimMs = audioStartTrimMs,
                endTrimMs = audioEndTrimMs,
                isTtsGenerated = audioIsTtsGenerated,
                ttsText = audioTtsText ?: "",
                ttsVoice = audioTtsVoice ?: "",
                ttsLanguage = audioTtsLanguage ?: "",
                ttsSpeed = audioTtsSpeed,
                ttsPitch = audioTtsPitch
            )
        } else null

        return ProjectItem(
            id = id,
            title = title,
            clipIds = clipList,
            audioItem = audio,
            loopStrategy = loopStrategy,
            customRepeatClipId = customRepeatClipId,
            audioStartOffsetSec = audioStartOffsetSec,
            audioEndOffsetSec = audioEndOffsetSec,
            audioVolume = audioVolume,
            videoVolume = videoVolume,
            exportPipEnabled = exportPipEnabled,
            pipClipId = pipClipId,
            pipPosition = pipPosition,
            pipScale = pipScale,
            createdAt = createdAt,
            updatedAt = updatedAt,
            lastExportedPath = lastExportedPath,
            lastExportDurationMs = lastExportDurationMs,
            lastExportFileSize = lastExportFileSize,
            lastExportSpeedFactor = lastExportSpeedFactor
        )
    }

    companion object {
        fun fromDomain(item: ProjectItem): ProjectEntity = ProjectEntity(
            id = item.id,
            title = item.title,
            clipIdsJson = item.clipIds.joinToString(","),
            loopStrategy = item.loopStrategy,
            customRepeatClipId = item.customRepeatClipId,
            audioStartOffsetSec = item.audioStartOffsetSec,
            audioEndOffsetSec = item.audioEndOffsetSec,
            audioVolume = item.audioVolume,
            videoVolume = item.videoVolume,
            audioId = item.audioItem?.id,
            audioTitle = item.audioItem?.title,
            audioDurationMs = item.audioItem?.durationMs,
            audioFilePath = item.audioItem?.filePath,
            audioUriString = item.audioItem?.uriString,
            audioVolumeField = item.audioItem?.volume ?: item.audioVolume,
            audioFadeInSec = item.audioItem?.fadeInSec ?: 0f,
            audioFadeOutSec = item.audioItem?.fadeOutSec ?: 0f,
            audioStartTrimMs = item.audioItem?.startTrimMs ?: 0L,
            audioEndTrimMs = item.audioItem?.endTrimMs ?: 0L,
            audioIsTtsGenerated = item.audioItem?.isTtsGenerated ?: false,
            audioTtsText = item.audioItem?.ttsText,
            audioTtsVoice = item.audioItem?.ttsVoice,
            audioTtsLanguage = item.audioItem?.ttsLanguage,
            audioTtsSpeed = item.audioItem?.ttsSpeed ?: 1.0f,
            audioTtsPitch = item.audioItem?.ttsPitch ?: 0,
            exportPipEnabled = item.exportPipEnabled,
            pipClipId = item.pipClipId,
            pipPosition = item.pipPosition,
            pipScale = item.pipScale,
            createdAt = item.createdAt,
            updatedAt = item.updatedAt,
            lastExportedPath = item.lastExportedPath,
            lastExportDurationMs = item.lastExportDurationMs,
            lastExportFileSize = item.lastExportFileSize,
            lastExportSpeedFactor = item.lastExportSpeedFactor
        )
    }
}
