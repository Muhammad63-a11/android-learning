package com.example.utils

import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

object GalleryHelper {

    /**
     * Saves an exported MP4 video directly to the device's public Phone Gallery
     * (Movies/AudiobookVideos directory) via MediaStore and MediaScannerConnection.
     */
    suspend fun saveVideoToGallery(
        context: Context,
        sourceFile: File,
        title: String
    ): Uri? = withContext(Dispatchers.IO) {
        if (!sourceFile.exists() || sourceFile.length() == 0L) {
            return@withContext null
        }

        val sanitizedTitle = title.replace(Regex("[^a-zA-Z0-9_\\-]"), "_").take(50)
        val fileName = "${sanitizedTitle}_${System.currentTimeMillis()}.mp4"
        val resolver = context.contentResolver

        var savedUri: Uri? = null

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val contentValues = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, fileName)
                    put(MediaStore.Video.Media.TITLE, title)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/AudiobookVideos")
                    put(MediaStore.Video.Media.IS_PENDING, 1)
                }

                val collectionUri = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
                savedUri = resolver.insert(collectionUri, contentValues)

                if (savedUri != null) {
                    resolver.openOutputStream(savedUri)?.use { outputStream ->
                        sourceFile.inputStream().use { inputStream ->
                            inputStream.copyTo(outputStream, bufferSize = 256 * 1024)
                        }
                    }
                    contentValues.clear()
                    contentValues.put(MediaStore.Video.Media.IS_PENDING, 0)
                    resolver.update(savedUri, contentValues, null, null)
                }
            } else {
                // For Android 9 and below: copy to public Movies directory
                val moviesDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "AudiobookVideos")
                moviesDir.mkdirs()
                val targetFile = File(moviesDir, fileName)
                sourceFile.copyTo(targetFile, overwrite = true)

                val contentValues = ContentValues().apply {
                    put(MediaStore.Video.Media.DATA, targetFile.absolutePath)
                    put(MediaStore.Video.Media.TITLE, title)
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                }
                savedUri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, contentValues)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // Trigger MediaScannerConnection to ensure phone gallery immediately discovers the video
        try {
            MediaScannerConnection.scanFile(
                context,
                arrayOf(sourceFile.absolutePath),
                arrayOf("video/mp4")
            ) { path, uri ->
                // Media scanned
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        savedUri
    }
}
