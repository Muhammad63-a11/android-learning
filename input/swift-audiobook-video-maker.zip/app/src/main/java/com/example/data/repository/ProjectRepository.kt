package com.example.data.repository

import com.example.data.db.ProjectDao
import com.example.data.db.ProjectEntity
import com.example.model.ProjectItem
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class ProjectRepository(private val projectDao: ProjectDao) {
    val allProjects: Flow<List<ProjectItem>> = projectDao.getAllProjects().map { entities ->
        entities.map { it.toDomain() }
    }

    val projectCount: Flow<Int> = projectDao.getProjectCount()

    val latestExportedProject: Flow<ProjectItem?> = projectDao.getLatestExportedProject().map { it?.toDomain() }

    suspend fun getProjectById(id: String): ProjectItem? {
        return projectDao.getProjectById(id)?.toDomain()
    }

    suspend fun saveProject(project: ProjectItem) {
        projectDao.insertProject(ProjectEntity.fromDomain(project))
    }

    suspend fun deleteProject(id: String) {
        projectDao.deleteProjectById(id)
    }
}
