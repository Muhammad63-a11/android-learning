package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.AppDatabase
import com.example.data.repository.ClipRepository
import com.example.data.repository.ProjectRepository
import com.example.engine.ExportResult
import com.example.engine.StreamCopyMuxer
import com.example.model.ArrangedTimeline
import com.example.model.AudioItem
import com.example.model.ClipItem
import com.example.model.LoopStrategy
import com.example.model.ProjectItem
import com.example.model.TtsVoice
import com.example.model.TtsVoiceCatalog
import com.example.tts.EdgeTtsService
import com.example.utils.SampleMediaHelper
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

enum class NavigationTab {
    HOME,
    LIBRARY,
    CREATE,
    SETTINGS
}

enum class SubScreen {
    NONE,
    CLIP_LIBRARY,
    PROJECT_EDITOR,
    EDGE_TTS,
    PREVIEW,
    EXPORTING,
    COMPLETED,
    PROJECTS_LIST
}

class AudiobookViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getInstance(application)
    private val clipRepository = ClipRepository(db.clipDao())
    private val projectRepository = ProjectRepository(db.projectDao())

    val allClips: StateFlow<List<ClipItem>> = clipRepository.allClips
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allProjects: StateFlow<List<ProjectItem>> = projectRepository.allProjects
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val clipCount: StateFlow<Int> = clipRepository.clipCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val projectCount: StateFlow<Int> = projectRepository.projectCount
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val latestExportedProject: StateFlow<ProjectItem?> = projectRepository.latestExportedProject
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    // Navigation State
    private val _currentTab = MutableStateFlow(NavigationTab.HOME)
    val currentTab: StateFlow<NavigationTab> = _currentTab.asStateFlow()

    private val _currentSubScreen = MutableStateFlow(SubScreen.NONE)
    val currentSubScreen: StateFlow<SubScreen> = _currentSubScreen.asStateFlow()

    // Active Project / Editor State
    private val _projectId = MutableStateFlow(UUID.randomUUID().toString())
    val projectId: StateFlow<String> = _projectId.asStateFlow()

    private val _projectTitle = MutableStateFlow("My Audiobook Video")
    val projectTitle: StateFlow<String> = _projectTitle.asStateFlow()

    private val _selectedClipIds = MutableStateFlow<List<String>>(emptyList())
    val selectedClipIds: StateFlow<List<String>> = _selectedClipIds.asStateFlow()

    private val _selectedAudio = MutableStateFlow<AudioItem?>(null)
    val selectedAudio: StateFlow<AudioItem?> = _selectedAudio.asStateFlow()

    private val _loopStrategy = MutableStateFlow(LoopStrategy.CENTER_CLIP_LOOP)
    val loopStrategy: StateFlow<LoopStrategy> = _loopStrategy.asStateFlow()

    private val _customRepeatClipId = MutableStateFlow<String?>(null)
    val customRepeatClipId: StateFlow<String?> = _customRepeatClipId.asStateFlow()

    // Audio Start Offset (Pre-roll delay, e.g. 8 sec into video)
    private val _audioStartOffsetSec = MutableStateFlow(0f)
    val audioStartOffsetSec: StateFlow<Float> = _audioStartOffsetSec.asStateFlow()

    // Audio End Offset (Post-roll padding, e.g. 8 sec before video ends)
    private val _audioEndOffsetSec = MutableStateFlow(0f)
    val audioEndOffsetSec: StateFlow<Float> = _audioEndOffsetSec.asStateFlow()

    // Volume controls
    private val _audioVolume = MutableStateFlow(1.0f) // 0% to 200%
    val audioVolume: StateFlow<Float> = _audioVolume.asStateFlow()

    private val _videoVolume = MutableStateFlow(0.0f) // 0% (Muted) to 100%
    val videoVolume: StateFlow<Float> = _videoVolume.asStateFlow()

    private val _arrangedTimeline = MutableStateFlow<ArrangedTimeline?>(null)
    val arrangedTimeline: StateFlow<ArrangedTimeline?> = _arrangedTimeline.asStateFlow()

    private val _isPipEnabled = MutableStateFlow(false)
    val isPipEnabled: StateFlow<Boolean> = _isPipEnabled.asStateFlow()

    // Export State
    private val _exportProgress = MutableStateFlow(0f)
    val exportProgress: StateFlow<Float> = _exportProgress.asStateFlow()

    private val _exportStatus = MutableStateFlow("")
    val exportStatus: StateFlow<String> = _exportStatus.asStateFlow()

    private val _currentExportSegment = MutableStateFlow(0)
    val currentExportSegment: StateFlow<Int> = _currentExportSegment.asStateFlow()

    private val _totalExportSegments = MutableStateFlow(0)
    val totalExportSegments: StateFlow<Int> = _totalExportSegments.asStateFlow()

    private val _exportResult = MutableStateFlow<ExportResult?>(null)
    val exportResult: StateFlow<ExportResult?> = _exportResult.asStateFlow()

    // Edge TTS state
    private val _ttsLanguage = MutableStateFlow("English")
    val ttsLanguage: StateFlow<String> = _ttsLanguage.asStateFlow()

    private val _ttsVoice = MutableStateFlow(TtsVoiceCatalog.voices.first())
    val ttsVoice: StateFlow<TtsVoice> = _ttsVoice.asStateFlow()

    private val _ttsSpeed = MutableStateFlow(1.0f)
    val ttsSpeed: StateFlow<Float> = _ttsSpeed.asStateFlow()

    private val _ttsPitch = MutableStateFlow(0)
    val ttsPitch: StateFlow<Int> = _ttsPitch.asStateFlow()

    private val _ttsText = MutableStateFlow("Chapter 1: The Cosmic Horizon.\nThe stars stretched endlessly into the midnight sky, whispering tales of forgotten worlds and ancient starlight.")
    val ttsText: StateFlow<String> = _ttsText.asStateFlow()

    private val _ttsGenerating = MutableStateFlow(false)
    val ttsGenerating: StateFlow<Boolean> = _ttsGenerating.asStateFlow()

    private val _ttsStatus = MutableStateFlow("")
    val ttsStatus: StateFlow<String> = _ttsStatus.asStateFlow()

    // Preview state
    private val _previewCurrentClipIndex = MutableStateFlow(0)
    val previewCurrentClipIndex: StateFlow<Int> = _previewCurrentClipIndex.asStateFlow()

    init {
        // Automatically check if clips exist, if not preload presets for immediate out-of-the-box readiness
        viewModelScope.launch {
            val clips = clipRepository.getClipsByIds(emptyList())
            if (clips.isEmpty()) {
                preloadPresetClips()
            }
        }
    }

    fun setTab(tab: NavigationTab) {
        _currentTab.value = tab
        _currentSubScreen.value = SubScreen.NONE
    }

    fun openSubScreen(screen: SubScreen) {
        _currentSubScreen.value = screen
    }

    fun navigateBack() {
        if (_currentSubScreen.value != SubScreen.NONE) {
            _currentSubScreen.value = SubScreen.NONE
        }
    }

    fun preloadPresetClips() {
        viewModelScope.launch {
            val presets = SampleMediaHelper.generatePresetClips(getApplication())
            clipRepository.saveClips(presets)
            if (_selectedClipIds.value.isEmpty() && presets.isNotEmpty()) {
                _selectedClipIds.value = presets.take(3).map { it.id }
                recomputeArrangement()
            }
        }
    }

    fun createNewProject(title: String = "My Audiobook Video") {
        _projectId.value = UUID.randomUUID().toString()
        _projectTitle.value = title.ifEmpty { "Audiobook_${System.currentTimeMillis() % 10000}" }
        val available = allClips.value
        _selectedClipIds.value = if (available.isNotEmpty()) available.take(3).map { it.id } else emptyList()
        _selectedAudio.value = null
        _loopStrategy.value = LoopStrategy.CENTER_CLIP_LOOP
        _customRepeatClipId.value = null
        _audioStartOffsetSec.value = 0f
        _audioEndOffsetSec.value = 0f
        _audioVolume.value = 1.0f
        _videoVolume.value = 0.0f
        _arrangedTimeline.value = null
        _exportResult.value = null
        _isPipEnabled.value = false
        _currentSubScreen.value = SubScreen.PROJECT_EDITOR
        recomputeArrangement()
    }

    fun loadProject(project: ProjectItem) {
        _projectId.value = project.id
        _projectTitle.value = project.title
        _selectedClipIds.value = project.clipIds
        _selectedAudio.value = project.audioItem
        _loopStrategy.value = try { LoopStrategy.valueOf(project.loopStrategy) } catch (_: Exception) { LoopStrategy.CENTER_CLIP_LOOP }
        _customRepeatClipId.value = project.customRepeatClipId
        _audioStartOffsetSec.value = project.audioStartOffsetSec
        _audioEndOffsetSec.value = project.audioEndOffsetSec
        _audioVolume.value = project.audioVolume
        _videoVolume.value = project.videoVolume
        _isPipEnabled.value = project.exportPipEnabled
        _exportResult.value = if (project.lastExportedPath != null) {
            ExportResult(
                success = true,
                outputPath = project.lastExportedPath,
                durationMs = project.lastExportDurationMs,
                fileSizeBytes = project.lastExportFileSize,
                elapsedMs = 1500L,
                speedFactor = project.lastExportSpeedFactor,
                modeUsed = "Pure Fast Stream-Copy"
            )
        } else null
        _currentSubScreen.value = SubScreen.PROJECT_EDITOR
        recomputeArrangement()
    }

    fun saveCurrentProject() {
        viewModelScope.launch {
            val project = ProjectItem(
                id = _projectId.value,
                title = _projectTitle.value,
                clipIds = _selectedClipIds.value,
                audioItem = _selectedAudio.value,
                loopStrategy = _loopStrategy.value.name,
                customRepeatClipId = _customRepeatClipId.value,
                audioStartOffsetSec = _audioStartOffsetSec.value,
                audioEndOffsetSec = _audioEndOffsetSec.value,
                audioVolume = _audioVolume.value,
                videoVolume = _videoVolume.value,
                exportPipEnabled = _isPipEnabled.value,
                updatedAt = System.currentTimeMillis(),
                lastExportedPath = _exportResult.value?.outputPath,
                lastExportDurationMs = _exportResult.value?.durationMs ?: 0L,
                lastExportFileSize = _exportResult.value?.fileSizeBytes ?: 0L,
                lastExportSpeedFactor = _exportResult.value?.speedFactor ?: 0f
            )
            projectRepository.saveProject(project)
        }
    }

    fun updateProjectTitle(newTitle: String) {
        _projectTitle.value = newTitle
        saveCurrentProject()
    }

    fun setLoopStrategy(strategy: LoopStrategy) {
        _loopStrategy.value = strategy
        recomputeArrangement()
        saveCurrentProject()
    }

    fun setCustomRepeatClipId(clipId: String?) {
        _customRepeatClipId.value = clipId
        recomputeArrangement()
        saveCurrentProject()
    }

    fun setAudioStartOffsetSec(seconds: Float) {
        _audioStartOffsetSec.value = seconds.coerceAtLeast(0f)
        recomputeArrangement()
        saveCurrentProject()
    }

    fun setAudioEndOffsetSec(seconds: Float) {
        _audioEndOffsetSec.value = seconds.coerceAtLeast(0f)
        recomputeArrangement()
        saveCurrentProject()
    }

    fun setAudioVolume(vol: Float) {
        _audioVolume.value = vol.coerceIn(0f, 2.0f)
        _selectedAudio.value?.let { current ->
            _selectedAudio.value = current.copy(volume = _audioVolume.value)
        }
        saveCurrentProject()
    }

    fun setVideoVolume(vol: Float) {
        _videoVolume.value = vol.coerceIn(0f, 1.0f)
        saveCurrentProject()
    }

    fun toggleClipSelection(clipId: String) {
        val current = _selectedClipIds.value.toMutableList()
        if (current.contains(clipId)) {
            current.remove(clipId)
        } else {
            current.add(clipId)
        }
        _selectedClipIds.value = current
        recomputeArrangement()
        saveCurrentProject()
    }

    fun addClipToSelection(clipId: String) {
        _selectedClipIds.value = _selectedClipIds.value + clipId
        recomputeArrangement()
        saveCurrentProject()
    }

    fun removeClipFromSelectionAt(index: Int) {
        val current = _selectedClipIds.value.toMutableList()
        if (index in current.indices) {
            current.removeAt(index)
            _selectedClipIds.value = current
            recomputeArrangement()
            saveCurrentProject()
        }
    }

    fun swapClips(index1: Int, index2: Int) {
        val list = _selectedClipIds.value.toMutableList()
        if (index1 in list.indices && index2 in list.indices && index1 != index2) {
            val temp = list[index1]
            list[index1] = list[index2]
            list[index2] = temp
            _selectedClipIds.value = list
            recomputeArrangement()
            saveCurrentProject()
        }
    }

    fun moveClipUp(index: Int) {
        if (index > 0 && index < _selectedClipIds.value.size) {
            val list = _selectedClipIds.value.toMutableList()
            val item = list.removeAt(index)
            list.add(index - 1, item)
            _selectedClipIds.value = list
            recomputeArrangement()
            saveCurrentProject()
        }
    }

    fun moveClipDown(index: Int) {
        if (index >= 0 && index < _selectedClipIds.value.size - 1) {
            val list = _selectedClipIds.value.toMutableList()
            val item = list.removeAt(index)
            list.add(index + 1, item)
            _selectedClipIds.value = list
            recomputeArrangement()
            saveCurrentProject()
        }
    }

    /**
     * Imports video from phone gallery into internal persistent storage and saves permanently in Room DB
     */
    fun importPremadeVideo(uri: Uri, context: Context) {
        viewModelScope.launch {
            try {
                val file = SampleMediaHelper.copyUriToInternalStorage(context, uri, "clip", "mp4")
                val duration = SampleMediaHelper.getMediaDuration(context, Uri.fromFile(file))
                val dims = SampleMediaHelper.getVideoDimensions(context, Uri.fromFile(file))
                val clip = ClipItem(
                    id = "clip_${UUID.randomUUID().toString().take(8)}",
                    title = file.nameWithoutExtension.replace('_', ' ').capitalizeFirst(),
                    durationMs = duration,
                    width = dims.first,
                    height = dims.second,
                    filePath = file.absolutePath,
                    uriString = Uri.fromFile(file).toString(),
                    isSample = false
                )
                clipRepository.saveClip(clip)
                // If currently editing project, auto-add to selection
                if (_currentSubScreen.value == SubScreen.PROJECT_EDITOR) {
                    addClipToSelection(clip.id)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun renameClip(id: String, newTitle: String) {
        viewModelScope.launch {
            clipRepository.updateTitle(id, newTitle)
        }
    }

    fun deleteClip(id: String) {
        viewModelScope.launch {
            clipRepository.deleteClip(id)
            if (_selectedClipIds.value.contains(id)) {
                _selectedClipIds.value = _selectedClipIds.value.filter { it != id }
                recomputeArrangement()
            }
        }
    }

    fun importAudioFile(uri: Uri, context: Context) {
        viewModelScope.launch {
            try {
                val file = SampleMediaHelper.copyUriToInternalStorage(context, uri, "audiobook_audio", "mp3")
                val duration = SampleMediaHelper.getMediaDuration(context, Uri.fromFile(file))
                val audio = AudioItem(
                    id = "audio_${UUID.randomUUID().toString().take(8)}",
                    title = file.nameWithoutExtension.replace('_', ' ').capitalizeFirst(),
                    durationMs = duration,
                    filePath = file.absolutePath,
                    uriString = Uri.fromFile(file).toString(),
                    volume = _audioVolume.value,
                    fadeInSec = 0f,
                    fadeOutSec = 0f,
                    isTtsGenerated = false
                )
                _selectedAudio.value = audio
                recomputeArrangement()
                saveCurrentProject()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun updateAudioControls(
        volume: Float,
        fadeInSec: Float,
        fadeOutSec: Float,
        startTrimMs: Long = 0L,
        endTrimMs: Long = 0L
    ) {
        val audio = _selectedAudio.value ?: return
        _audioVolume.value = volume
        _selectedAudio.value = audio.copy(
            volume = volume,
            fadeInSec = fadeInSec,
            fadeOutSec = fadeOutSec,
            startTrimMs = startTrimMs,
            endTrimMs = endTrimMs
        )
        recomputeArrangement()
        saveCurrentProject()
    }

    fun removeAudio() {
        _selectedAudio.value = null
        recomputeArrangement()
        saveCurrentProject()
    }

    fun setPipEnabled(enabled: Boolean) {
        _isPipEnabled.value = enabled
        saveCurrentProject()
    }

    // Edge TTS Configuration
    fun setTtsLanguage(lang: String) {
        _ttsLanguage.value = lang
        val voicesInLang = TtsVoiceCatalog.getVoicesForLanguage(lang)
        if (voicesInLang.isNotEmpty()) {
            _ttsVoice.value = voicesInLang.first()
        }
    }

    fun setTtsVoice(voice: TtsVoice) {
        _ttsVoice.value = voice
    }

    fun setTtsSpeed(speed: Float) {
        _ttsSpeed.value = speed
    }

    fun setTtsPitch(pitch: Int) {
        _ttsPitch.value = pitch
    }

    fun setTtsText(text: String) {
        _ttsText.value = text
    }

    fun generateNarration() {
        viewModelScope.launch {
            _ttsGenerating.value = true
            _ttsStatus.value = "Starting Edge TTS synthesis..."
            try {
                val audioItem = EdgeTtsService.generateNarration(
                    context = getApplication(),
                    text = _ttsText.value,
                    voice = _ttsVoice.value,
                    speed = _ttsSpeed.value,
                    pitch = _ttsPitch.value,
                    onProgress = { _ttsStatus.value = it }
                )
                _selectedAudio.value = audioItem.copy(volume = _audioVolume.value)
                recomputeArrangement()
                saveCurrentProject()
                _ttsStatus.value = "Generated successfully!"
                _currentSubScreen.value = SubScreen.PROJECT_EDITOR
            } catch (e: Exception) {
                _ttsStatus.value = "Error: ${e.message}"
            } finally {
                _ttsGenerating.value = false
            }
        }
    }

    fun recomputeArrangement() {
        viewModelScope.launch {
            val clipMap = allClips.value.associateBy { it.id }
            val clipsInOrder = _selectedClipIds.value.mapNotNull { clipMap[it] }
            val audio = _selectedAudio.value
            val targetAudioDuration = audio?.effectiveDurationMs ?: 60000L // 1 min preview default if no audio

            val startOffsetMs = (_audioStartOffsetSec.value * 1000L).toLong()
            val endOffsetMs = (_audioEndOffsetSec.value * 1000L).toLong()

            val timeline = ArrangedTimeline.calculate(
                selectedClips = clipsInOrder,
                audioDurationMs = targetAudioDuration,
                audioStartOffsetMs = startOffsetMs,
                audioEndOffsetMs = endOffsetMs,
                loopStrategy = _loopStrategy.value,
                customRepeatClipId = _customRepeatClipId.value
            )
            _arrangedTimeline.value = timeline
        }
    }

    fun startFastExport(context: Context) {
        val timeline = _arrangedTimeline.value
        val audio = _selectedAudio.value ?: run {
            val defaultAudioFile = File(context.filesDir, "default_audio.mp4")
            AudioItem(
                id = "default_audio",
                title = "Narration Track",
                durationMs = 60000L,
                filePath = defaultAudioFile.absolutePath,
                volume = _audioVolume.value
            )
        }

        if (timeline == null || timeline.segments.isEmpty()) return

        _currentSubScreen.value = SubScreen.EXPORTING
        _exportProgress.value = 0f
        _exportStatus.value = "Starting pure fast stream-copy muxer..."

        viewModelScope.launch {
            val result = StreamCopyMuxer.exportAudiobookVideo(
                context = context,
                timeline = timeline,
                audioItem = audio,
                audioVolume = _audioVolume.value,
                videoVolume = _videoVolume.value,
                isPipEnabled = _isPipEnabled.value,
                onProgress = { progress, status, segIndex, totalSegs ->
                    _exportProgress.value = progress
                    _exportStatus.value = status
                    _currentExportSegment.value = segIndex
                    _totalExportSegments.value = totalSegs
                }
            )
            _exportResult.value = result
            if (result.success) {
                saveCurrentProject()
                _currentSubScreen.value = SubScreen.COMPLETED
            } else {
                _exportStatus.value = "Export error: ${result.errorMessage}"
            }
        }
    }

    fun deleteProject(id: String) {
        viewModelScope.launch {
            projectRepository.deleteProject(id)
        }
    }

    private fun String.capitalizeFirst(): String {
        return this.replaceFirstChar { if (it.isLowerCase()) it.titlecase(java.util.Locale.ROOT) else it.toString() }
    }
}
