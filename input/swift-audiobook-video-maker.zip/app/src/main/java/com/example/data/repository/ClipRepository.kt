package com.example.data.repository

import com.example.data.db.ClipDao
import com.example.data.db.ClipEntity
import com.example.model.ClipItem
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class ClipRepository(private val clipDao: ClipDao) {
    val allClips: Flow<List<ClipItem>> = clipDao.getAllClips().map { entities ->
        entities.map { it.toDomain() }
    }

    val clipCount: Flow<Int> = clipDao.getClipCount()

    suspend fun getClipById(id: String): ClipItem? {
        return clipDao.getClipById(id)?.toDomain()
    }

    suspend fun getClipsByIds(ids: List<String>): List<ClipItem> {
        val map = clipDao.getClipsByIds(ids).associateBy { it.id }
        // Preserve input ordering
        return ids.mapNotNull { map[it]?.toDomain() }
    }

    suspend fun saveClip(clip: ClipItem) {
        clipDao.insertClip(ClipEntity.fromDomain(clip))
    }

    suspend fun saveClips(clips: List<ClipItem>) {
        clipDao.insertClips(clips.map { ClipEntity.fromDomain(it) })
    }

    suspend fun updateTitle(id: String, newTitle: String) {
        clipDao.updateClipTitle(id, newTitle)
    }

    suspend fun deleteClip(id: String) {
        clipDao.deleteClipById(id)
    }
}
