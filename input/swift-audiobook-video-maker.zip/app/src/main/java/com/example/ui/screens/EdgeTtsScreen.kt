package com.example.ui.screens

import android.media.MediaPlayer
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.TtsVoice
import com.example.model.TtsVoiceCatalog
import com.example.ui.theme.AmberAccent
import com.example.ui.theme.AmberContainer
import com.example.ui.theme.GreenSuccess
import com.example.ui.theme.SkyAccent
import com.example.ui.theme.SlateBorder
import com.example.ui.theme.SlateCardSurface
import com.example.ui.theme.SlateDarkBackground
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.AudiobookViewModel
import java.io.File
import java.util.Locale

@Composable
fun EdgeTtsScreen(
    viewModel: AudiobookViewModel,
    modifier: Modifier = Modifier,
    onBack: () -> Unit
) {
    val selectedLanguage by viewModel.ttsLanguage.collectAsState()
    val selectedVoice by viewModel.ttsVoice.collectAsState()
    val speed by viewModel.ttsSpeed.collectAsState()
    val pitch by viewModel.ttsPitch.collectAsState()
    val text by viewModel.ttsText.collectAsState()
    val isGenerating by viewModel.ttsGenerating.collectAsState()
    val statusMsg by viewModel.ttsStatus.collectAsState()
    val currentAudio by viewModel.selectedAudio.collectAsState()

    val scrollState = rememberScrollState()
    val langScrollState = rememberScrollState()

    val voicesForSelectedLang = remember(selectedLanguage) {
        TtsVoiceCatalog.getVoicesForLanguage(selectedLanguage)
    }

    var mediaPlayer by remember { mutableStateOf<MediaPlayer?>(null) }
    var isPlayingAudio by remember { mutableStateOf(false) }

    DisposableEffect(Unit) {
        onDispose {
            mediaPlayer?.release()
            mediaPlayer = null
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(SlateDarkBackground)
            .verticalScroll(scrollState)
            .padding(horizontal = 20.dp, vertical = 16.dp)
    ) {
        // Top bar
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = TextPrimary
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Voice Generation",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Spacer(modifier = Modifier.weight(1f))
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color(0xFF10281E),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF10B981))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF10B981))
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "CLOUD NEURAL",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF10B981),
                        letterSpacing = 0.5.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Text(
            text = "Generate natural human-like voice narration in any language with studio-quality neural voices.",
            style = MaterialTheme.typography.bodyMedium,
            color = TextSecondary,
            lineHeight = 20.sp
        )

        Spacer(modifier = Modifier.height(20.dp))

        // 1. Language Picker (Full Names)
        Text(
            text = "1. SELECT LANGUAGE",
            style = MaterialTheme.typography.labelSmall,
            letterSpacing = 1.sp,
            fontWeight = FontWeight.Bold,
            color = TextMuted
        )

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(langScrollState),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TtsVoiceCatalog.languages.forEach { lang ->
                val isSelected = lang.equals(selectedLanguage, ignoreCase = true)
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (isSelected) AmberAccent else Color(0xFF16212D))
                        .border(
                            1.dp,
                            if (isSelected) AmberAccent else Color(0xFF263546),
                            RoundedCornerShape(12.dp)
                        )
                        .clickable { viewModel.setTtsLanguage(lang) }
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                ) {
                    Text(
                        text = lang,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        color = if (isSelected) Color.Black else TextPrimary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 2. Character & Voice Selector
        Text(
            text = "2. CHOOSE CHARACTER VOICE (${voicesForSelectedLang.size} available in $selectedLanguage)",
            style = MaterialTheme.typography.labelSmall,
            letterSpacing = 1.sp,
            fontWeight = FontWeight.Bold,
            color = TextMuted
        )

        Spacer(modifier = Modifier.height(8.dp))

        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            voicesForSelectedLang.forEach { voice ->
                val isVoiceSelected = voice.voiceId == selectedVoice.voiceId
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .clickable { viewModel.setTtsVoice(voice) },
                    color = if (isVoiceSelected) Color(0xFF2A2016) else SlateCardSurface,
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isVoiceSelected) AmberAccent else SlateBorder
                    )
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(if (isVoiceSelected) AmberAccent else Color(0xFF1B2838)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.RecordVoiceOver,
                                    contentDescription = null,
                                    tint = if (isVoiceSelected) Color.Black else SkyAccent,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = voice.characterName,
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimary
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "• ${voice.gender}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (isVoiceSelected) AmberAccent else TextMuted
                                    )
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = voice.style,
                                    style = MaterialTheme.typography.bodySmall,
                                    fontSize = 11.sp,
                                    color = TextSecondary
                                )
                            }
                        }

                        if (isVoiceSelected) {
                            Icon(
                                imageVector = Icons.Default.Check,
                                contentDescription = "Selected",
                                tint = AmberAccent,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 3. Voice Controls (Speed & Pitch)
        Text(
            text = "3. SPEED & PITCH CONTROLS",
            style = MaterialTheme.typography.labelSmall,
            letterSpacing = 1.sp,
            fontWeight = FontWeight.Bold,
            color = TextMuted
        )

        Spacer(modifier = Modifier.height(8.dp))

        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            color = SlateCardSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, SlateBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                // Speed
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Narration Speed",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextPrimary
                    )
                    Text(
                        text = String.format(Locale.US, "%.2fx", speed),
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = AmberAccent
                    )
                }
                Slider(
                    value = speed,
                    onValueChange = { viewModel.setTtsSpeed(it) },
                    valueRange = 0.5f..2.0f,
                    steps = 14,
                    colors = SliderDefaults.colors(
                        thumbColor = AmberAccent,
                        activeTrackColor = AmberAccent,
                        inactiveTrackColor = Color(0xFF283648)
                    )
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Pitch
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Pitch Tuning",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextPrimary
                    )
                    Text(
                        text = if (pitch > 0) "+$pitch" else "$pitch",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = SkyAccent
                    )
                }
                Slider(
                    value = pitch.toFloat(),
                    onValueChange = { viewModel.setTtsPitch(it.toInt()) },
                    valueRange = -10f..10f,
                    steps = 19,
                    colors = SliderDefaults.colors(
                        thumbColor = SkyAccent,
                        activeTrackColor = SkyAccent,
                        inactiveTrackColor = Color(0xFF283648)
                    )
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // 4. Audiobook Text Input
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "4. AUDIOBOOK TEXT",
                style = MaterialTheme.typography.labelSmall,
                letterSpacing = 1.sp,
                fontWeight = FontWeight.Bold,
                color = TextMuted
            )

            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                SamplePromptChip("Sci-Fi") {
                    viewModel.setTtsText("Chapter 1: The Quantum Nebula.\nThrough the silence of deep space, the starship's engines hummed softly, drifting past glittering belts of cosmic dust.")
                }
                SamplePromptChip("Fantasy") {
                    viewModel.setTtsText("Prologue: The Forgotten Kingdom.\nDeep within the misty whispering woods, an ancient ruined tower guarded secrets long lost to mortal men.")
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = text,
            onValueChange = { viewModel.setTtsText(it) },
            modifier = Modifier
                .fillMaxWidth()
                .height(140.dp)
                .testTag("tts_text_input"),
            shape = RoundedCornerShape(14.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary,
                focusedContainerColor = SlateCardSurface,
                unfocusedContainerColor = SlateCardSurface,
                focusedBorderColor = AmberAccent,
                unfocusedBorderColor = SlateBorder
            ),
            placeholder = { Text("Paste or type your chapter or narration script here...", color = TextMuted) }
        )

        if (statusMsg.isNotBlank()) {
            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = statusMsg,
                style = MaterialTheme.typography.bodySmall,
                color = if (statusMsg.startsWith("Error")) Color(0xFFEF4444) else AmberAccent
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Generate Action Button
        Button(
            onClick = { viewModel.generateNarration() },
            enabled = !isGenerating && text.isNotBlank(),
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
                .testTag("generate_tts_button"),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = AmberAccent,
                contentColor = Color.Black
            )
        ) {
            if (isGenerating) {
                CircularProgressIndicator(
                    color = Color.Black,
                    modifier = Modifier.size(22.dp),
                    strokeWidth = 2.5.dp
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "Synthesizing Audio...",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
            } else {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = null,
                    tint = Color.Black,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Generate Narration Audio",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        Spacer(modifier = Modifier.height(40.dp))
    }
}

@Composable
private fun SamplePromptChip(title: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF1B2838))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.labelSmall,
            color = SkyAccent,
            fontSize = 10.sp
        )
    }
}
