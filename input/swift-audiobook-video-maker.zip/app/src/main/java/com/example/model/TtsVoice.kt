package com.example.model

data class TtsVoice(
    val voiceId: String,
    val characterName: String,
    val languageName: String,
    val languageCode: String,
    val gender: String,
    val style: String
)

object TtsVoiceCatalog {
    val languages = listOf(
        "English",
        "Urdu",
        "Hindi",
        "Arabic",
        "Spanish",
        "French",
        "German",
        "Italian",
        "Portuguese",
        "Russian",
        "Chinese",
        "Japanese",
        "Korean",
        "Turkish",
        "Polish",
        "Dutch",
        "Bengali",
        "Indonesian",
        "Vietnamese",
        "Swedish",
        "Filipino",
        "Thai",
        "Tamil",
        "Telugu",
        "Ukrainian"
    )

    val voices = listOf(
        // English (US, UK, AU, CA, IN)
        TtsVoice("en-US-JennyNeural", "Jenny", "English", "en-US", "Female", "Natural, conversational, friendly narrator"),
        TtsVoice("en-US-GuyNeural", "Guy", "English", "en-US", "Male", "Warm, authoritative audiobook voice"),
        TtsVoice("en-US-AriaNeural", "Aria", "English", "en-US", "Female", "Expressive, literary fiction storyteller"),
        TtsVoice("en-US-ChristopherNeural", "Christopher", "English", "en-US", "Male", "Deep baritone, classic narrator"),
        TtsVoice("en-US-EricNeural", "Eric", "English", "en-US", "Male", "Energetic, clear documentary style"),
        TtsVoice("en-US-MichelleNeural", "Michelle", "English", "en-US", "Female", "Calm, soothing storytelling"),
        TtsVoice("en-US-RogerNeural", "Roger", "English", "en-US", "Male", "Mature, distinguished book reader"),
        TtsVoice("en-US-SteffanNeural", "Steffan", "English", "en-US", "Male", "Crisp, dynamic presenter"),
        TtsVoice("en-GB-SoniaNeural", "Sonia", "English", "en-GB", "Female", "British refined classical narration"),
        TtsVoice("en-GB-RyanNeural", "Ryan", "English", "en-GB", "Male", "British distinguished storyteller"),
        TtsVoice("en-GB-LibbyNeural", "Libby", "English", "en-GB", "Female", "British modern conversational"),
        TtsVoice("en-AU-NatashaNeural", "Natasha", "English", "en-AU", "Female", "Australian natural cadence"),
        TtsVoice("en-AU-WilliamNeural", "William", "English", "en-AU", "Male", "Australian friendly baritone"),
        TtsVoice("en-CA-ClaraNeural", "Clara", "English", "en-CA", "Female", "Canadian clear narrative"),
        TtsVoice("en-CA-LiamNeural", "Liam", "English", "en-CA", "Male", "Canadian expressive storytelling"),
        TtsVoice("en-IN-NeerjaNeural", "Neerja", "English", "en-IN", "Female", "Indian English eloquent storyteller"),
        TtsVoice("en-IN-PrabhatNeural", "Prabhat", "English", "en-IN", "Male", "Indian English warm narrator"),

        // Urdu (Pakistan & India)
        TtsVoice("ur-PK-AsadNeural", "Asad", "Urdu", "ur-PK", "Male", "Eloquent classical Urdu orator"),
        TtsVoice("ur-PK-UzmaNeural", "Uzma", "Urdu", "ur-PK", "Female", "Melodious, expressive Urdu storytelling"),
        TtsVoice("ur-IN-GulNeural", "Gul", "Urdu", "ur-IN", "Female", "Poetic classical Urdu tone"),
        TtsVoice("ur-IN-SalmanNeural", "Salman", "Urdu", "ur-IN", "Male", "Deep formal Urdu narration"),

        // Hindi (India)
        TtsVoice("hi-IN-SwaraNeural", "Swara", "Hindi", "hi-IN", "Female", "Clear resonant Hindi narration"),
        TtsVoice("hi-IN-MadhurNeural", "Madhur", "Hindi", "hi-IN", "Male", "Warm engaging Hindi storytelling"),

        // Arabic (Saudi, Egypt, UAE)
        TtsVoice("ar-SA-HamedNeural", "Hamed", "Arabic", "ar-SA", "Male", "Eloquent classical Arab orator"),
        TtsVoice("ar-SA-ZariyahNeural", "Zariyah", "Arabic", "ar-SA", "Female", "Classical Arabic literature tone"),
        TtsVoice("ar-EG-SalmaNeural", "Salma", "Arabic", "ar-EG", "Female", "Warm Egyptian narrative"),
        TtsVoice("ar-EG-ShakirNeural", "Shakir", "Arabic", "ar-EG", "Male", "Deep Egyptian storyteller"),
        TtsVoice("ar-AE-FatimaNeural", "Fatima", "Arabic", "ar-AE", "Female", "Emirati refined reading"),
        TtsVoice("ar-AE-HamdanNeural", "Hamdan", "Arabic", "ar-AE", "Male", "Emirati formal narration"),

        // Spanish (Spain, Mexico, US)
        TtsVoice("es-ES-AlvaroNeural", "Alvaro", "Spanish", "es-ES", "Male", "Rich Spanish audiobook tone"),
        TtsVoice("es-ES-ElviraNeural", "Elvira", "Spanish", "es-ES", "Female", "Castilian dramatic storyteller"),
        TtsVoice("es-MX-DaliaNeural", "Dalia", "Spanish", "es-MX", "Female", "Latin American expressive narrator"),
        TtsVoice("es-MX-JorgeNeural", "Jorge", "Spanish", "es-MX", "Male", "Mexican warm conversational voice"),
        TtsVoice("es-US-AlonsoNeural", "Alonso", "Spanish", "es-US", "Male", "US Spanish clear narrator"),
        TtsVoice("es-US-PalomaNeural", "Paloma", "Spanish", "es-US", "Female", "US Spanish melodious tone"),

        // French (France & Canada)
        TtsVoice("fr-FR-DeniseNeural", "Denise", "French", "fr-FR", "Female", "Elegant Parisian literature narrator"),
        TtsVoice("fr-FR-HenriNeural", "Henri", "French", "fr-FR", "Male", "Smooth sophisticated French reader"),
        TtsVoice("fr-FR-EloiseNeural", "Eloise", "French", "fr-FR", "Female", "Warm emotional French storyteller"),
        TtsVoice("fr-CA-SylvieNeural", "Sylvie", "French", "fr-CA", "Female", "Canadian French literary tone"),
        TtsVoice("fr-CA-AntoineNeural", "Antoine", "French", "fr-CA", "Male", "Canadian French resonant voice"),

        // German (Germany & Austria)
        TtsVoice("de-DE-KatjaNeural", "Katja", "German", "de-DE", "Female", "Precise expressive German voice"),
        TtsVoice("de-DE-ConradNeural", "Conrad", "German", "de-DE", "Male", "Authoritative classic German narrator"),
        TtsVoice("de-DE-KillianNeural", "Killian", "German", "de-DE", "Male", "Contemporary German storyteller"),
        TtsVoice("de-AT-IngridNeural", "Ingrid", "German", "de-AT", "Female", "Austrian German warm tone"),
        TtsVoice("de-AT-JonasNeural", "Jonas", "German", "de-AT", "Male", "Austrian German clear narrator"),

        // Italian
        TtsVoice("it-IT-DiegoNeural", "Diego", "Italian", "it-IT", "Male", "Warm theatrical Italian reader"),
        TtsVoice("it-IT-ElsaNeural", "Elsa", "Italian", "it-IT", "Female", "Passionate melodious cadence"),
        TtsVoice("it-IT-IsabellaNeural", "Isabella", "Italian", "it-IT", "Female", "Classic Italian literary voice"),

        // Portuguese (Brazil & Portugal)
        TtsVoice("pt-BR-FranciscaNeural", "Francisca", "Portuguese", "pt-BR", "Female", "Warm Brazilian narrator"),
        TtsVoice("pt-BR-AntonioNeural", "Antonio", "Portuguese", "pt-BR", "Male", "Deep expressive Brazilian baritone"),
        TtsVoice("pt-PT-RaquelNeural", "Raquel", "Portuguese", "pt-PT", "Female", "European Portuguese classic voice"),
        TtsVoice("pt-PT-DuarteNeural", "Duarte", "Portuguese", "pt-PT", "Male", "European Portuguese distinguished reader"),

        // Russian
        TtsVoice("ru-RU-SvetlanaNeural", "Svetlana", "Russian", "ru-RU", "Female", "Rich Russian literary voice"),
        TtsVoice("ru-RU-DmitryNeural", "Dmitry", "Russian", "ru-RU", "Male", "Deep baritone epic narrator"),

        // Chinese (Mandarin, Taiwanese, Cantonese)
        TtsVoice("zh-CN-XiaoxiaoNeural", "Xiaoxiao", "Chinese", "zh-CN", "Female", "Warm storytelling Mandarin voice"),
        TtsVoice("zh-CN-YunxiNeural", "Yunxi", "Chinese", "zh-CN", "Male", "Dynamic theatrical novel reader"),
        TtsVoice("zh-CN-YunjianNeural", "Yunjian", "Chinese", "zh-CN", "Male", "Epic historical narrative voice"),
        TtsVoice("zh-CN-XiaoyiNeural", "Xiaoyi", "Chinese", "zh-CN", "Female", "Gentle novel reading"),
        TtsVoice("zh-TW-HsiaoChenNeural", "HsiaoChen", "Chinese", "zh-TW", "Female", "Taiwanese Mandarin melodious voice"),
        TtsVoice("zh-TW-YunJheNeural", "YunJhe", "Chinese", "zh-TW", "Male", "Taiwanese Mandarin steady narrator"),
        TtsVoice("zh-HK-HiuMaanNeural", "HiuMaan", "Chinese", "zh-HK", "Female", "Cantonese Hong Kong storyteller"),
        TtsVoice("zh-HK-WanLungNeural", "WanLung", "Chinese", "zh-HK", "Male", "Cantonese Hong Kong distinguished voice"),

        // Japanese
        TtsVoice("ja-JP-NanamiNeural", "Nanami", "Japanese", "ja-JP", "Female", "Gentle light novel narrator"),
        TtsVoice("ja-JP-KeitaNeural", "Keita", "Japanese", "ja-JP", "Male", "Deep serene Japanese voice"),

        // Korean
        TtsVoice("ko-KR-SunHiNeural", "SunHi", "Korean", "ko-KR", "Female", "Soft emotional narrative"),
        TtsVoice("ko-KR-InJoonNeural", "InJoon", "Korean", "ko-KR", "Male", "Clear steady audiobook voice"),

        // Turkish
        TtsVoice("tr-TR-EmelNeural", "Emel", "Turkish", "tr-TR", "Female", "Smooth modern Turkish reader"),
        TtsVoice("tr-TR-AhmetNeural", "Ahmet", "Turkish", "tr-TR", "Male", "Deep expressive Turkish narrator"),

        // Polish
        TtsVoice("pl-PL-ZofiaNeural", "Zofia", "Polish", "pl-PL", "Female", "Expressive Polish storyteller"),
        TtsVoice("pl-PL-MarekNeural", "Marek", "Polish", "pl-PL", "Male", "Rich baritone Polish narration"),

        // Dutch (Netherlands & Belgium)
        TtsVoice("nl-NL-FennaNeural", "Fenna", "Dutch", "nl-NL", "Female", "Clear natural Dutch reader"),
        TtsVoice("nl-NL-MaartenNeural", "Maarten", "Dutch", "nl-NL", "Male", "Warm engaging Dutch storyteller"),
        TtsVoice("nl-BE-DenaNeural", "Dena", "Dutch", "nl-BE", "Female", "Flemish Belgian smooth tone"),
        TtsVoice("nl-BE-ArnaudNeural", "Arnaud", "Dutch", "nl-BE", "Male", "Flemish Belgian clear narrator"),

        // Bengali (India & Bangladesh)
        TtsVoice("bn-IN-TanishaaNeural", "Tanishaa", "Bengali", "bn-IN", "Female", "Melodic Bengali reading"),
        TtsVoice("bn-IN-BashkarNeural", "Bashkar", "Bengali", "bn-IN", "Male", "Resonant Bengali storyteller"),
        TtsVoice("bn-BD-NabanitaNeural", "Nabanita", "Bengali", "bn-BD", "Female", "Warm Bangladeshi narrative voice"),
        TtsVoice("bn-BD-PradeepNeural", "Pradeep", "Bengali", "bn-BD", "Male", "Classic poetic tone"),

        // Indonesian
        TtsVoice("id-ID-GadisNeural", "Gadis", "Indonesian", "id-ID", "Female", "Warm natural Indonesian voice"),
        TtsVoice("id-ID-ArdiNeural", "Ardi", "Indonesian", "id-ID", "Male", "Clear steady Indonesian narration"),

        // Vietnamese
        TtsVoice("vi-VN-HoaiMyNeural", "HoaiMy", "Vietnamese", "vi-VN", "Female", "Expressive Vietnamese storyteller"),
        TtsVoice("vi-VN-NamMinhNeural", "NamMinh", "Vietnamese", "vi-VN", "Male", "Resonant Vietnamese narrative tone"),

        // Swedish
        TtsVoice("sv-SE-SofieNeural", "Sofie", "Swedish", "sv-SE", "Female", "Calm Nordic audiobook voice"),
        TtsVoice("sv-SE-MattiasNeural", "Mattias", "Swedish", "sv-SE", "Male", "Deep resonant Swedish reader"),

        // Filipino (Tagalog)
        TtsVoice("fil-PH-BlessicaNeural", "Blessica", "Filipino", "fil-PH", "Female", "Natural Filipino storyteller"),
        TtsVoice("fil-PH-AngeloNeural", "Angelo", "Filipino", "fil-PH", "Male", "Warm conversational Filipino narrator"),

        // Thai
        TtsVoice("th-TH-PremwadeeNeural", "Premwadee", "Thai", "th-TH", "Female", "Smooth melodic Thai voice"),
        TtsVoice("th-TH-NiwatNeural", "Niwat", "Thai", "th-TH", "Male", "Formal resonant Thai speaker"),

        // Tamil
        TtsVoice("ta-IN-PallaviNeural", "Pallavi", "Tamil", "ta-IN", "Female", "Eloquent Tamil literary voice"),
        TtsVoice("ta-IN-ValluvarNeural", "Valluvar", "Tamil", "ta-IN", "Male", "Classic Tamil narrator"),

        // Telugu
        TtsVoice("te-IN-ShrutiNeural", "Shruti", "Telugu", "te-IN", "Female", "Clear melodious Telugu voice"),
        TtsVoice("te-IN-MohanNeural", "Mohan", "Telugu", "te-IN", "Male", "Warm engaging Telugu reader"),

        // Ukrainian
        TtsVoice("uk-UA-PolinaNeural", "Polina", "Ukrainian", "uk-UA", "Female", "Expressive Ukrainian storyteller"),
        TtsVoice("uk-UA-OstapNeural", "Ostap", "Ukrainian", "uk-UA", "Male", "Deep Ukrainian narrator")
    )

    fun getVoicesForLanguage(languageName: String): List<TtsVoice> {
        return voices.filter { it.languageName.equals(languageName, ignoreCase = true) }
    }
}
