package com.example.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.model.ClipItem

@Entity(tableName = "clips")
data class ClipEntity(
    @PrimaryKey val id: String,
    val title: String,
    val durationMs: Long,
    val width: Int,
    val height: Int,
    val fps: Float,
    val filePath: String,
    val uriString: String,
    val isSample: Boolean,
    val createdAt: Long
) {
    fun toDomain(): ClipItem = ClipItem(
        id = id,
        title = title,
        durationMs = durationMs,
        width = width,
        height = height,
        fps = fps,
        filePath = filePath,
        uriString = uriString,
        isSample = isSample,
        createdAt = createdAt
    )

    companion object {
        fun fromDomain(item: ClipItem): ClipEntity = ClipEntity(
            id = item.id,
            title = item.title,
            durationMs = item.durationMs,
            width = item.width,
            height = item.height,
            fps = item.fps,
            filePath = item.filePath,
            uriString = item.uriString,
            isSample = item.isSample,
            createdAt = item.createdAt
        )
    }
}
