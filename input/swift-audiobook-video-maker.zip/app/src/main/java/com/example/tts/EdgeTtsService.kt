package com.example.tts

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.util.Log
import com.example.model.AudioItem
import com.example.model.TtsVoice
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

object EdgeTtsService {

    private const val TAG = "EdgeTtsService"
    private const val TRUSTED_CLIENT_TOKEN = "6A5AA1D4EAFF4E9FB37E23D68491D6F4"
    private const val SEC_MS_GEC_VERSION = "1-130.0.2849.68"

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .retryOnConnectionFailure(true)
        .build()

    /**
     * Calculates the Microsoft Sec-MS-GEC DRM token based on Windows epoch
     */
    private fun getSecMsGec(): String {
        try {
            // Seconds between Windows epoch (1601-01-01) and Unix epoch (1970-01-01)
            val winEpoch = 11644473600L
            val unixTimestamp = System.currentTimeMillis() / 1000L
            // 100-nanosecond intervals since Windows epoch
            val ticks = (unixTimestamp + winEpoch) * 10000000L
            // Round down to nearest 5-minute interval (300 seconds * 10000000 = 3000000000)
            val roundedTicks = ticks - (ticks % 3000000000L)
            val strToHash = "$roundedTicks$TRUSTED_CLIENT_TOKEN"
            val md = MessageDigest.getInstance("SHA-256")
            val digest = md.digest(strToHash.toByteArray(Charsets.US_ASCII))
            return digest.joinToString("") { "%02x".format(it) }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to compute Sec-MS-GEC token", e)
            return ""
        }
    }

    private fun isNetworkAvailable(context: Context): Boolean {
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return false
        val activeNetwork = connectivityManager.activeNetwork ?: return false
        val capabilities = connectivityManager.getNetworkCapabilities(activeNetwork) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    suspend fun generateNarration(
        context: Context,
        text: String,
        voice: TtsVoice,
        speed: Float = 1.0f,
        pitch: Int = 0,
        onProgress: (String) -> Unit = {}
    ): AudioItem = withContext(Dispatchers.IO) {
        val cleanText = text.trim().ifEmpty { "Welcome to the audiobook. Enjoy this audio narration experience." }
        val outputDir = File(context.filesDir, "tts_audio").apply { mkdirs() }
        val audioFile = File(outputDir, "EdgeTTS_${voice.characterName}_${System.currentTimeMillis()}.mp3")

        val speedRateStr = String.format(Locale.US, "%+d%%", ((speed - 1.0f) * 100).toInt())
        val pitchStr = String.format(Locale.US, "%+dHz", pitch * 5)
        val ssml = buildSsml(cleanText, voice.voiceId, speedRateStr, pitchStr)

        var audioData: ByteArray? = null
        val online = isNetworkAvailable(context)

        if (online) {
            onProgress("Connecting to Cloud Neural Voice...")
            try {
                audioData = requestEdgeTtsWebSocket(ssml, onProgress)
            } catch (e: Exception) {
                Log.e(TAG, "Cloud TTS WebSocket error", e)
            }

            // Secondary Online Cloud TTS Fallback (Google Cloud Voice Engine)
            if (audioData == null || audioData.size < 1024) {
                onProgress("Connecting to Secondary Cloud Voice Engine...")
                try {
                    audioData = requestGoogleTranslateTts(cleanText, voice.languageCode, onProgress)
                } catch (e: Exception) {
                    Log.e(TAG, "Secondary Cloud Voice error", e)
                }
            }
        }

        if (audioData != null && audioData.size > 500) {
            FileOutputStream(audioFile).use { it.write(audioData) }
            onProgress("Neural cloud voice generated successfully!")
        } else {
            // Offline local voice engine fallback
            if (!online) {
                onProgress("No internet detected. Generating with local voice engine...")
            } else {
                onProgress("Cloud engines unavailable. Fallback to local voice engine...")
            }

            val wavFallbackFile = File(outputDir, "TTS_local_${System.currentTimeMillis()}.wav")
            val nativeSuccess = AndroidSpeechTtsEngine.synthesizeTextToFile(
                context = context,
                text = cleanText,
                outputFile = wavFallbackFile,
                speed = speed,
                pitch = 1.0f + (pitch * 0.1f)
            )

            if (nativeSuccess && wavFallbackFile.exists() && wavFallbackFile.length() > 0) {
                val finalAac = com.example.engine.AudioTranscoder.convertToM4aAac(context, wavFallbackFile)
                if (finalAac.exists() && finalAac.length() > 500) {
                    finalAac.copyTo(audioFile, overwrite = true)
                    try { finalAac.delete() } catch (_: Exception) {}
                } else {
                    wavFallbackFile.copyTo(audioFile, overwrite = true)
                }
                try { wavFallbackFile.delete() } catch (_: Exception) {}
            } else {
                throw IllegalStateException("Failed to synthesize voice. Please check system speech settings.")
            }
        }

        // Extract duration
        val durationMs = extractDuration(audioFile)
        onProgress("Narration ready! (${durationMs / 1000}s)")

        AudioItem(
            id = "tts_${UUID.randomUUID()}",
            title = "${voice.characterName} • ${voice.languageName} (Neural)",
            durationMs = durationMs,
            filePath = audioFile.absolutePath,
            uriString = audioFile.toURI().toString(),
            volume = 1.0f,
            fadeInSec = 0f,
            fadeOutSec = 0f,
            isTtsGenerated = true,
            ttsText = cleanText,
            ttsVoice = voice.voiceId,
            ttsLanguage = voice.languageName,
            ttsSpeed = speed,
            ttsPitch = pitch
        )
    }

    private fun requestGoogleTranslateTts(
        text: String,
        langCode: String,
        onProgress: (String) -> Unit
    ): ByteArray? {
        return try {
            val chunks = splitTextForTts(text, maxChunkLen = 160)
            val output = ByteArrayOutputStream()

            for ((index, chunk) in chunks.withIndex()) {
                onProgress("Streaming Cloud Voice (${index + 1}/${chunks.size})...")
                val encodedText = java.net.URLEncoder.encode(chunk, "UTF-8")
                val lang = if (langCode.length >= 2) langCode.take(2).lowercase() else "en"
                val url = "https://translate.google.com/translate_tts?ie=UTF-8&q=$encodedText&tl=$lang&client=tw-ob"

                val req = Request.Builder()
                    .url(url)
                    .addHeader("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36")
                    .addHeader("Referer", "https://translate.google.com/")
                    .build()

                client.newCall(req).execute().use { response ->
                    if (response.isSuccessful) {
                        val bytes = response.body?.bytes()
                        if (bytes != null && bytes.isNotEmpty()) {
                            output.write(bytes)
                        }
                    } else {
                        Log.w(TAG, "Google TTS chunk $index response code ${response.code}")
                    }
                }
            }

            if (output.size() > 500) output.toByteArray() else null
        } catch (e: Exception) {
            Log.e(TAG, "Google Translate TTS exception", e)
            null
        }
    }

    private fun splitTextForTts(text: String, maxChunkLen: Int): List<String> {
        val result = mutableListOf<String>()
        val sentences = text.split(Regex("(?<=[.!?;\n])\\s+"))
        var current = StringBuilder()

        for (sentence in sentences) {
            if (current.length + sentence.length + 1 <= maxChunkLen) {
                if (current.isNotEmpty()) current.append(" ")
                current.append(sentence)
            } else {
                if (current.isNotEmpty()) {
                    result.add(current.toString())
                    current = StringBuilder()
                }
                if (sentence.length <= maxChunkLen) {
                    current.append(sentence)
                } else {
                    val words = sentence.split(" ")
                    for (word in words) {
                        if (current.length + word.length + 1 <= maxChunkLen) {
                            if (current.isNotEmpty()) current.append(" ")
                            current.append(word)
                        } else {
                            if (current.isNotEmpty()) {
                                result.add(current.toString())
                                current = StringBuilder()
                            }
                            current.append(word)
                        }
                    }
                }
            }
        }
        if (current.isNotEmpty()) {
            result.add(current.toString())
        }
        return if (result.isEmpty()) listOf(text.take(maxChunkLen)) else result
    }

    private fun escapeXml(str: String): String {
        return str
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
            .replace("'", "&apos;")
    }

    private fun buildSsml(text: String, voiceName: String, rate: String, pitch: String): String {
        val escapedText = escapeXml(text)
        return """
            <speak version='1.0' xmlns='http://www.w3.org/2001/10/synthesis' xml:lang='en-US'>
                <voice name='$voiceName'>
                    <prosody pitch='$pitch' rate='$rate' volume='+0%'>
                        $escapedText
                    </prosody>
                </voice>
            </speak>
        """.trimIndent()
    }

    private fun requestEdgeTtsWebSocket(ssml: String, onProgress: (String) -> Unit): ByteArray? {
        val audioStream = ByteArrayOutputStream()
        val latch = CountDownLatch(1)
        var errorOccurred = false
        var receivedTurnEnd = false

        val secMsGec = getSecMsGec()
        val connectionId = UUID.randomUUID().toString().replace("-", "")

        val wsUrl = if (secMsGec.isNotEmpty()) {
            "wss://speech.platform.bing.com/consumer/speech/synthesize/readaloud/edge/v1" +
                    "?TrustedClientToken=$TRUSTED_CLIENT_TOKEN" +
                    "&Sec-MS-GEC=$secMsGec" +
                    "&Sec-MS-GEC-Version=$SEC_MS_GEC_VERSION" +
                    "&ConnectionId=$connectionId"
        } else {
            "wss://speech.platform.bing.com/consumer/speech/synthesize/readaloud/edge/v1" +
                    "?TrustedClientToken=$TRUSTED_CLIENT_TOKEN" +
                    "&ConnectionId=$connectionId"
        }

        val request = Request.Builder()
            .url(wsUrl)
            .addHeader("Pragma", "no-cache")
            .addHeader("Cache-Control", "no-cache")
            .addHeader("Origin", "chrome-extension://jdiccldimpdaibmpdkjnbmckianbfold")
            .addHeader("Accept-Encoding", "gzip, deflate, br")
            .addHeader("Accept-Language", "en-US,en;q=0.9")
            .addHeader("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36 Edg/130.0.0.0")
            .build()

        val webSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                onProgress("Synthesizing Microsoft Edge Cloud Voice...")
                val timestamp = SimpleDateFormat("EEE MMM dd yyyy HH:mm:ss 'GMT'Z (zzzz)", Locale.US).format(Date())

                // 1. Send speech.config message
                val configMsg = "Content-Type:application/json; charset=utf-8\r\nPath:speech.config\r\n\r\n" +
                        "{\"context\":{\"synthesis\":{\"audio\":{\"metadataoptions\":{\"sentenceBoundaryEnabled\":\"false\",\"wordBoundaryEnabled\":\"false\"}," +
                        "\"outputFormat\":\"audio-24khz-48kbitrate-mono-mp3\"}}}}\r\n"
                webSocket.send(configMsg)

                // 2. Send SSML message
                val requestId = UUID.randomUUID().toString().replace("-", "")
                val ssmlMsg = "X-RequestId:$requestId\r\nContent-Type:application/ssml+xml\r\nX-Timestamp:$timestamp\r\nPath:ssml\r\n\r\n$ssml"
                webSocket.send(ssmlMsg)
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                if (text.contains("Path:turn.end")) {
                    receivedTurnEnd = true
                    webSocket.close(1000, "Done")
                    latch.countDown()
                } else if (text.contains("Path:turn.start")) {
                    onProgress("Streaming voice packets...")
                }
            }

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                val data = bytes.toByteArray()
                // Edge TTS binary messages have a 2-byte header size (Big Endian) followed by ASCII headers, then raw audio bytes
                if (data.size > 2) {
                    val headerLen = ((data[0].toInt() and 0xFF) shl 8) or (data[1].toInt() and 0xFF)
                    val audioOffset = 2 + headerLen
                    if (data.size > audioOffset) {
                        audioStream.write(data, audioOffset, data.size - audioOffset)
                    }
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                Log.e(TAG, "WebSocket failure: ${t.message}, response=$response")
                errorOccurred = true
                latch.countDown()
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                latch.countDown()
            }
        })

        try {
            val completed = latch.await(25, TimeUnit.SECONDS)
            if (!completed) {
                webSocket.cancel()
            }
        } catch (_: Exception) {
            webSocket.cancel()
        }

        return if (!errorOccurred && audioStream.size() > 1024) audioStream.toByteArray() else null
    }

    private fun extractDuration(file: File): Long {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(file.absolutePath)
            val durationStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            durationStr?.toLongOrNull() ?: 10000L
        } catch (e: Exception) {
            10000L
        } finally {
            try { retriever.release() } catch (_: Exception) {}
        }
    }
}
